-- 1.count the members who has gold cards
select count(customer_id) from customer_card_details where card_id in
(select card_id from library_card_master where descrition like 'gold');

-- display the name of member who issued movie and the count of the 
-- movies issued and display 0 for the member who have not issued any movie
select cm.customer_name,count(cd.issue_id)count
from customer_master cm,customer_issue_details cd
where cm.customer_id=cd.customer_id
group by cd.customer_id
union
select customer_name,0 as count from  customer_master 
where customer_id not in (select customer_id from customer_issue_details);

-- 3.display the name of the person starting with letter 'r' and category is 'comedy'


-- display id,name & total rent of customers for movie issued
select c.customer_id,c.customer_name,(count(d.movie_id)*m.rent_cost)total_rent
from customer_master c,customer_issue_details d,movies_master m where
c.customer_id=d.customer_id and d.movie_id=m.movie_id
group by d.customer_id;
-- 5.display id,name,card id,amount in $(amount/54.42) upto 0 decimals


-- 6.display id,name of customers who dont have library card but still have issued the movie
select customer_id,customer_name from customer_master where customer_id not in
(select customer_id from customer_card_details) and customer_id in
(select customer_id from customer_issue_details);
