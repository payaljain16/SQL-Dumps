
/* ** Insert values in table called LMS_MEMBERS ** */

Insert into LMS_MEMBERS
Values('LM001', 'AMIT', 'CHENNAI', date_format('2012-02-12','%Y-%m-%d'), date_format('2013-02-11','%Y-%m-%d'),'Temporary');

Insert into LMS_MEMBERS
Values('LM002', 'ABDHUL', 'DELHI', date_format('2012-04-10','%Y-%m-%d'), date_format('2013-04-09','%Y-%m-%d'),'Temporary');

Insert into LMS_MEMBERS
Values('LM003', 'GAYAN', 'CHENNAI', date_format('2013-05-12','%Y-%m-%d'),date_format('2013-05-14','%Y-%m-%d'), 'Permanent');

Insert into LMS_MEMBERS
Values('LM004', 'RADHA', 'CHENNAI', date_format('2012-04-22','%Y-%m-%d'), date_format('2013-04-21','%Y-%m-%d'), 'Temporary');

Insert into LMS_MEMBERS
Values('LM005', 'GURU', 'BANGALORE', date_format('2012-03-30','%Y-%m-%d'), date_format('2013-03-29','%Y-%m-%d'),'Temporary');

Insert into LMS_MEMBERS
Values('LM006', 'MOHAN', 'CHENNAI', date_format('2012-04-12','%Y-%m-%d'), date_format('2013-04-12','%Y-%m-%d'),'Temporary');


select * from lms_members;





/* ** Insert values in table called LMS_SUPPLIERS_DETAILS ** */


Insert into  LMS_SUPPLIERS_DETAILS 
Values ('S01','SINGAPORE SHOPPEE', 'CHENNAI', 9894123555,'sing@gmail.com');

Insert into  LMS_SUPPLIERS_DETAILS 
Values ('S02','JK Stores', 'MUMBAI', 9940123450 ,'jks@yahoo.com');

Insert into  LMS_SUPPLIERS_DETAILS 
Values ('S03','ROSE BOOK STORE', 'TRIVANDRUM', 9444411222,'rose@gmail.com');

Insert into  LMS_SUPPLIERS_DETAILS 
Values ('S04','KAVARI STORE', 'DELHI', 8630001452,'kavi@redif.com');

Insert into  LMS_SUPPLIERS_DETAILS 
Values ('S05','EINSTEN BOOK GALLARY', 'US', 9542000001,'eingal@aol.com');

Insert into  LMS_SUPPLIERS_DETAILS 
Values ('S06','AKBAR STORE', 'MUMBAI',7855623100 ,'akbakst@aol.com');

Insert into  LMS_SUPPLIERS_DETAILS(SUPPLIER_ID,SUPPLIER_NAME,
	CONTACT,EMAIL) Values ('S07','AKBAR STORE',7855623100 ,'akbakst@aol.com');




/* ** Insert values in table called LMS_FINE_DETAILS ** */


Insert into LMS_FINE_DETAILS Values('R1', 20);

insert into LMS_FINE_DETAILS Values('R2', 50);

Insert into LMS_FINE_DETAILS Values('R3', 75);

Insert into LMS_FINE_DETAILS Values('R4', 100);

Insert into LMS_FINE_DETAILS Values('R5', 150);

Insert into LMS_FINE_DETAILS Values('R6', 200);

      


/* ** Insert values in table called LMS_BOOK_DETAILS ** */


Insert into LMS_BOOK_DETAILS
Values('BL000001', 'Java How To Do Program', 'JAVA', 'Paul J. Deitel', 'Prentice Hall', date_format('1999-12-10','%Y-%m-%d'), 6, 600.00, 'A1', date_format('2011-05-10','%Y-%m-%d'), 'S01');

Insert into LMS_BOOK_DETAILS
Values('BL000002', 'Java: The Complete Reference ', 'JAVA', 'Herbert Schildt',  'Tata Mcgraw Hill ', date_format('2011-10-10','%Y-%m-%d'), 5, 750.00, 'A1', date_format('2011-05-10','%Y-%m-%d'), 'S03');

Insert into LMS_BOOK_DETAILS 
Values('BL000003', 'Java How To Do Program', 'JAVA', 'Paul J. Deitel', 'Prentice Hall', date_format('1999-12-10','%Y-%m-%d'), 6, 600.00, 'A1', date_format('2012-05-12','%Y-%m-%d'), 'S01');

Insert into LMS_BOOK_DETAILS
Values('BL000004', 'Java: The Complete Reference ', 'JAVA', 'Herbert Schildt', 'Tata Mcgraw Hill ', date_format('2011-10-10','%Y-%m-%d'), 5, 750.00, 'A1', date_format('2012-05-12','%Y-%m-%d'), 'S01');

Insert into LMS_BOOK_DETAILS 
Values('BL000005', 'Java How To Do Program', 'JAVA', 'Paul J. Deitel',  'Prentice Hall', date_format('1999-12-10','%Y-%m-%d'), 6, 600.00, 'A1', date_format('2012-05-12','%Y-%m-%d'), 'S01');

Insert into LMS_BOOK_DETAILS
Values('BL000006', 'Java: The Complete Reference ', 'JAVA', 'Herbert Schildt', 'Tata Mcgraw Hill ', date_format('2011-10-10','%Y-%m-%d'), 5, 750.00, 'A1', date_format('2012-05-12','%Y-%m-%d'), 'S03');

Insert into LMS_BOOK_DETAILS 
Values('BL000007', 'Let Us C', 'C', 'Yashavant Kanetkar ', 'BPB Publications', date_format('2010-12-11','%Y-%m-%d'),  9, 500.00 , 'A3', date_format('2010-01-03','%Y-%m-%d'), 'S03');

Insert into LMS_BOOK_DETAILS 
Values('BL000008', 'Let Us C', 'C', 'Yashavant Kanetkar ','BPB Publications', date_format('2010-12-11','%Y-%m-%d'),  9, 500.00 , 'A3', date_format('2010-01-03','%Y-%m-%d'), 'S04');

       

/* ** Insert values in table called LMS_BOOK_ISSUE ** */


Insert into LMS_BOOK_ISSUE 
Values (001, 'LM001', 'BL000001', date_format('2012-05-01','%Y-%m-%d'), date_format('2012-05-16','%Y-%m-%d'), date_format('2012-05-16','%Y-%m-%d'),'N', 'R1');

Insert into LMS_BOOK_ISSUE 
Values (002, 'LM002', 'BL000002', date_format('2012-04-20','%Y-%m-%d'), date_format('2012-05-06','%Y-%m-%d'),date_format('2012-05-04','%Y-%m-%d'), 'N', 'R2');

Insert into LMS_BOOK_ISSUE
Values (003, 'LM003', 'BL000007', date_format('2012-04-01','%Y-%m-%d'), date_format('2012-04-16','%Y-%m-%d'), date_format('2012-04-20','%Y-%m-%d'),'Y','R1');

Insert into LMS_BOOK_ISSUE 
Values (004, 'LM004', 'BL000005', date_format('2012-04-01','%Y-%m-%d'), date_format('2012-04-16','%Y-%m-%d'),date_format('2012-04-20','%Y-%m-%d'), 'Y', 'R1');

Insert into LMS_BOOK_ISSUE 
Values (005, 'LM005', 'BL000008', date_format('2012-03-30','%Y-%m-%d'), date_format('2012-04-15','%Y-%m-%d'),date_format('2012-04-20','%Y-%m-%d') ,'N', 'R2');






