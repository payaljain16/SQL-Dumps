/*Average Questions:
Problem # 1:
Write a query to display the member id, member name of the members, book code and book title
of the books taken by them.*/
select lm.member_id,lm.member_name,lbd.book_code,lbd.book_title
from lms_members lm
inner join
lms_book_issue lbi
on lm.member_id=lbi.member_id
inner join
lms_book_details lbd
on lbi.book_code=lbd.book_code;

/*Problem # 2:
Write a query to display the total number of books available in the library with alias 
name “NO_OF_BOOKS_AVAILABLE” (Which is not issued). Hint: The issued books details are available 
in the LMS_BOOK_ISSUE table. */
select count(*) NO_OF_BOOKS_AVAILABLE  from lms_book_issue
where book_issue_status='N';

/*Problem # 3:
Write a query to display the member id, member name, fine range and fine amount of the members
whose fine amount is less than 100. */

select lm.member_id,lm.member_name,lfd.fine_range,lfd.fine_amount
from 
lms_fine_details lfd
inner join
lms_book_issue lbi
on
lfd.fine_range=lbi.fine_range
inner join
lms_members lm
on lbi.member_id=lm.member_id
where lfd.fine_amount<100;

/*Problem # 4:
Write a query to display the book code, book title, publisher, edition, price and year of 
publication and sort based on year of publication, publisher and edition.*/
select book_code,book_title,publication,
book_edition,price,Date_format(publish_date,'%Y')
from 
lms_book_details
order by publication,book_edition;

/*Problem # 5:
Write a query to display the book code, book title and rack number of the books which are placed 
in rack 'A1' and sort by book title in ascending order. */
select book_code,book_title,rack_num
from lms_book_details
where rack_num='A1'
order by book_title;

/*Problem # 6:
Write a query to display the member id, member name, due date and date returned of the 
members who has returned the books after the due date. Hint: Date_return is due date and 
Date_returned is actual book return date. */
select * from lms_members;
select * from lms_book_issue;

select lm.member_id,lm.member_name, lbi.date_return,lbi.date_returned
from lms_book_issue lbi
inner join
lms_members lm
on lbi.member_id=lm.member_id
where lbi.date_returned>lbi.date_return;

/*Problem # 7:
Write a query to display the member id, member name and date of registration who have not 
taken any book. */

select * 
from lms_members lm
inner join
lms_book_issue lbi
on lm.member_id=lbi.member_id;

select * 
from lms_members lm;
/*Problem # 8:
Write a Query to display the member id and member name of the members who has not paid 
any fine in the year 2012.*/
select * from lms_book_issue
where date_returned>date_return
and date_format(date_returned,'%Y')='2012';

/*Problem # 9:
Write a query to display the date on which the maximum numbers of books were issued and 
the number of books issued with alias name “NOOFBOOKS”.*/
select max(counted),di from
(
    select count(date_issue) counted,date_issue di from
    lms_book_issue
    group by date_issue
) count;

select count(date_issue) counted,date_issue di from
    lms_book_issue
    group by date_issue;
    
/*Problem # 10:
Write a query to list the book title and supplier id for the books authored by
“Herbert Schildt" and the book edition is 5 and supplied by supplier ‘S01’. */
select lbd.book_title,lbd.supplier_id 
from 
lms_book_details lbd
inner join
lms_suppliers_details lsd
on lbd.supplier_id=lsd.supplier_id
where lbd.author='Herbert Schildt'
and
lbd.book_edition=5;

/*Problem # 11:
Write a query to display the rack number and the number of books in each rack with
alias name “NOOFBOOKS” and sort by rack number in ascending order.*/
select rack_num,count(rack_num) NOOFBOOKS
from
lms_book_details
group by rack_num
order by rack_num;

/*Problem # 12:
Write a query to display book issue number, member name, date or registration, 
date of expiry, book title, category author, price, date of issue, date of return, 
actual returned date, issue status, fine amount.*/ 
select  lbi.book_issue_no,lm.member_name,lm.date_register,lm.date_expire,
lbd.book_title,lbd.category,lbd.author,lbd.price,lbi.date_issue,
lbi.date_return,lbi.date_returned,lbi.book_issue_status,lfd.fine_range
from lms_book_issue lbi
inner join
lms_members lm
on
lbi.member_id=lm.member_id
inner join
lms_book_details lbd
on
lbi.book_code=lbd.book_code
inner join
lms_fine_details lfd
on lbi.fine_range=lfd.fine_range;

/*Problem # 13:
Write a query to display the book code, title, publish date of the books which is been 
published in the month of December. */
select book_code,book_title,publish_date from lms_book_details
where 
date_format(publish_date,'%m')='12';
/*Problem # 14:
Write a query to display the book code, book title ,supplier name and price of the 
book witch takes maximum price based on each supplier.*/
select lbd.book_code,lbd.book_title,lsd.supplier_name,max(lbd.price)
from lms_book_details lbd
inner join
lms_suppliers_details lsd
on
lbd.supplier_id=lsd.supplier_id
group by lbd.supplier_id;
/*Problem # 15:
Write a query to display book code, book name, and publisher, how old the book is. 
Sorted as older to newer.
*/
select book_code,book_title,publication,
date_format(current_date,'%Y')-date_format(publish_date,'%Y') 
from 
lms_book_details
order by publish_date;