select book_code,supplier_id from lms_book_details 
where  category='java'  or supplier_id='s01';
select category,price, from lms_book_details
limit 5;
select p.price"p1",price"p2",(p1-p2)"s" from lms_book_code p,(select d.price"p2" from lms_book_details d where book_code='bl000002') where p.book_code='bl000001';
select now()"currentdate";
SELECT TOP '5'
FROM lms_book_details;
select category from lms_book_details where category like '[j-c]%';
select abs(t.prices) from (select distinct((select price from lms_book_details where book_code='bl000001') - 
(select price from lms_book_details where book_code='bl000002'))"prices")t ;
select * from lms_fine_details f union all  select * from lms_suppliers_details s; 
select book_code,price,book_title into books in lmsbackup from lms_book_details;
select sysdate();
select current_date;
select current_time;
select current_timestamp;
select t