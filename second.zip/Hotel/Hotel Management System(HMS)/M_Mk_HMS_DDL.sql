create table HMS_TARIFF(
RTYPE 	char(2) Primary key, 
RDESC 	varchar(20) ,
PRICE 	INT(4) 
);

create table HMS_ROOMS(
RNO 	INT(3) Primary key, 
RTYPE 	char(2), 
FLOOR 	INT(2) ,
STATUS 	char(1),
constraint FK1 FOREIGN KEY  (RTYPE)
 REFERENCES HMS_TARIFF(RTYPE) 
);

create table HMS_CUSTOMERS(
RNO 	INT(3) ,
CNAME 	varchar(20) ,
ADDRESS 	varchar(20) ,
PURPOSE 	varchar(30) ,
CHECKIN 	datetime ,
ADVANCE 	INT(5) ,
constraint FK2 FOREIGN KEY  (RNO)
 REFERENCES HMS_ROOMS(RNO) 
);

create table HMS_SERVICES(
RNO 	INT(3) ,
STYPE 	char(1) ,
SDESC 	varchar(20) ,
AMT 	INT(5) ,
RDATE   date, 
constraint FK3 foreign key (RNO)
references HMS_CUSTOMERS(RNO)
);

/*
drop table  HMS_SERVICES;
drop table  HMS_CUSTOMERS;
drop table  HMS_ROOMS;
drop table  HMS_TARIFF;
*/
