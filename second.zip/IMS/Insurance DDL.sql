create database insurancedb;
use insurancedb;

create table address_details(address_id int primary key,h_no varchar(6),city varchar(50),
addressline1 varchar(50),state varchar(50),pin varchar(50));

create table user_details(user_id int primary key,firstname varchar(50),lastname varchar(50),
email varchar(50),mobileno varchar(50),address_id int references address_details(address_id),dob date);

create table ref_policy_types(policy_type_code varchar(10) primary key,policy_type_name varchar(50));

create table policy_sub_types(policy_type_id varchar(10) primary key,
policy_type_code varchar(10) references ref_policy_types(policy_type_code),description varchar(50),
yearsofpayements int,amount double,maturityperiod int,maturityamount double,validity int);

create table user_policies(policy_no varchar(20) primary key,user_id int references user_details(user_id),
date_registered date,policy_type_id varchar(10) references policy_sub_types(policy_type_id) );

create table policy_payments(receipno int primary key,user_id int references user_details(user_id),
policy_no varchar(20) references user_policies(policy_no),dateofpayment date,amount double,fine double);

