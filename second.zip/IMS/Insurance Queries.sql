/*1.Write a query to display the policytypeid,policytypename,description of all the car’s policy details.*/

select p.policy_type_id,r.policy_type_name,p.description from 
ref_policy_types r
inner join
policy_sub_types p
on
r.policy_type_code=p.policy_type_code;


/*2.Write a query to display the policytypecode,no of polycies in each code with alias name NO_OF_POLICIES.*/

select policy_type_code,count(policy_type_code) NO_OF_POLICIES
from policy_sub_types
group by policy_type_code;

/*3.Write a query to display the userid,firstname,lastname, email,mobileno who are residing in Chennai.*/
select u.address_id,user_id,firstname,lastname,email,mobileno from user_details u
inner join
address_details a
on u.address_id=a.address_id
where a.city='chennai';
/*4.Write a query to display the userid, firstname lastname with alias name USER_NAME,email,
mobileno who has taken the car polycies.*/
select ud.user_id,concat(ud.firstname,' ',ud.lastname)  USER_NAME,ud.email,ud.mobileno 
from 
user_details ud
inner join
user_policies u
on u.user_id=ud.user_id
inner join
policy_sub_types p
on u.policy_type_id=p.policy_type_id
inner join
ref_policy_types r
on p.policy_type_code=r.policy_type_code
where r.policy_type_name ='car';

/*5.Write a query to display the userid, firstname,last name who has taken the car policies but 
not home ploicies.*/
select u.user_id,u1.firstname,u1.lastname from user_policies u
inner join
policy_sub_types p
on u.policy_type_id=p.policy_type_id
inner join ref_policy_types r
on r.policy_type_code=p.policy_type_code
inner join user_details u1
on u.user_id=u1.user_id
where u.user_id not in  
    (select user_id from user_policies
     where policy_type_id in     
        (select policy_type_id from policy_sub_types
        where policy_type_code in 
            (select policy_type_code from ref_policy_types
            where policy_type_name='home')))
and r.policy_type_name='car';

/*6.Write a query to display the policytypecode, policytype name which 
policytype has maximum no of policies.*/

select p.policy_type_code,r.policy_type_name from 
user_policies u
inner join
policy_sub_types p
on u.policy_type_id=p.policy_type_id
inner join ref_policy_types r
on p.policy_type_code=r.policy_type_code
group by u.policy_type_id
having count(u.policy_type_id)=
(
    select max(pol) from
    (
        select count(u.policy_type_id) pol from user_policies u
        group by u.policy_type_id
    )T1
);

/*7.Write a query to display the userid, firtsname, lastname, city state whose 
city is ending with ‘bad’.*/
select u.user_id,u.firstname,u.lastname,a.city from user_details u
inner join
address_details a
on u.address_id=a.address_id
where a.city like '%bad';

/*8.Write a query to display the userid, firstname, lastname ,ploicyno, dateregistered who has 
registered before may 2012.*/

select u.user_id,u1.firstname,u1.lastname,u.policy_no,u.date_registered
from user_policies u
inner join
user_details u1
on u.user_id=u1.user_id
where u.date_registered<'2012-05-01';

/*9.Write a query to display the userid, firstname, lastname who has taken more than one policies.*/
select u.user_id,u1.firstname,u1.lastname from user_policies u
inner join user_details u1
on u.user_id=u1.user_id
group by u.user_id
having count(u.user_id)>1;

/*10.Write a query to display the policytypecode, policytypename, policytypeid, userid,
ploicyno whose maturity will fall in the month of august 2013.*/
select * from policy_sub_types p
inner join
user_policies u
on p.policy_type_id=u.policy_type_id;

/*11.Write a query to display the policytypecode, policytypename, policytypeid whose 
maturity amount is the double than the total paid amount.*/


select 
r.policy_type_code,r.policy_type_name,ps.policy_type_id
from user_policies u 
inner join
policy_payments p
on u.user_id=p.user_id
and u.policy_no=p.policy_no

inner join
policy_sub_types ps
on u.policy_type_id=ps.policy_type_id

inner join
ref_policy_types r
on r.policy_type_code=ps.policy_type_code
group by p.user_id,p.policy_no;
 

/*
12.Write a query to display the userid, total amount paid by the customer with
alias name total_amount.*/

select user_id,sum(amount) total_amount from policy_payments
group by user_id;

/*
13.Write a query to display the  user_id, policy_no, total amount paid by 
the customer for the each policies.*/
select user_id,policy_no,sum(amount) from policy_payments
group by user_id,policy_no;

/*14.Write a query to display the user_id, policy_no, balance_amount for each policies.*/
select 
u.user_id,u.policy_no,
ps.maturityamount-sum(p.amount) balance_amount

from user_policies u 
inner join
policy_payments p
on u.user_id=p.user_id
and u.policy_no=p.policy_no

inner join
policy_sub_types ps
on u.policy_type_id=ps.policy_type_id

inner join
ref_policy_types r
on r.policy_type_code=ps.policy_type_code
group by p.user_id,p.policy_no;


/*15.write a query to display the user_id,policy_no, balancepayment years with alias name 
BALANCE_YEARS for all the customer for each policies.*/


/*16.Write a query to display the user details userid,firstname,lastname who has taken car, 
home and life loans.*/


/*17.Write a query to select policy_type_code,total amount  paid by all the customers  
with alias name total_amount  for each policy department.*/
select 
r.policy_type_code,sum(p.amount)

from user_policies u 
inner join
policy_payments p
on u.user_id=p.user_id
and u.policy_no=p.policy_no

inner join
policy_sub_types ps
on u.policy_type_id=ps.policy_type_id

inner join
ref_policy_types r
on r.policy_type_code=ps.policy_type_code
group by r.policy_type_code;

/*18.Write a query to select user_id,user_name,policy_type_code,policy_type_id of users
who has registered more than one policy type unde same policy code.*/
select u.user_id,count(p.policy_type_code)
from user_policies u
inner join
policy_sub_types p
on u.policy_type_id=p.policy_type_id
inner join
ref_policy_types r
on r.policy_type_code=p.policy_type_code
group by u.user_id,p.policy_type_code
having count(distinct(p.policy_type_id)) >1;

/*19.Write a query to display the policy_type_code,policytype name in which policy department 
has min number of policies registered.*/

select r.policy_type_code,r.policy_type_name from user_policies u
inner join
policy_sub_types p
on u.policy_type_id=p.policy_type_id
inner join
ref_policy_types r
on r.policy_type_code=p.policy_type_code
group by u.policy_type_id
having count(u.policy_type_id)=
(
    select min(num) from
    (
        select count(policy_type_id) num,policy_type_id from user_policies u
        group by policy_type_id
    ) t1
);
/*
20.Write a query to display the user_id,user_name, address,phoneno,policytypecode,
policytypeid,policytypename, who has complemented all payements for the policies.*/
select 
u.user_id,ud.firstname,ud.lastname,ud.mobileno,ps.policy_type_code,ps.policy_type_id,
r.policy_type_name,
ps.maturityamount,sum(p.amount)

from user_policies u 
inner join
policy_payments p
on u.user_id=p.user_id
and u.policy_no=p.policy_no

inner join
policy_sub_types ps
on u.policy_type_id=ps.policy_type_id

inner join
ref_policy_types r
on r.policy_type_code=ps.policy_type_code
inner join user_details ud
on u.user_id=ud.user_id
group by p.user_id,p.policy_no;
/*
21.write a query to display the user_id, user_name, address,phoneno,policytypecode,policytypeid,policytypename,date ofd register who has registered latest 2.
