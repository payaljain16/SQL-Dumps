use employee;
create table Distributor
(
Distributor_ID varchar(10) ,
Distributor_Name varchar(20),
Address varchar(100),
Mobile numeric(10),
Email varchar(30), constraint pk_distributor primary key(Distributor_ID) );

-- Mobile master table
create table Mobile_Master
(
IME_No varchar(10), Model_Name varchar(20), Manufacturer varchar(20), Date_Of_Manufac date,
Warranty_in_Years numeric, Price numeric(7,2), Distributor_ID varchar(10),
constraint pk_ime primary key(IME_No),foreign key(Distributor_ID) references Distributor(Distributor_ID)
);

-- Mobile specification table
create table Mobile_Specification
(
IME_No varchar(10), Dimension varchar(20), Weight varchar(20),Display_Type varchar(20), Display_Size varchar(20),
Internal_mem_in_MB numeric, Memory_Card_Capacity_GB numeric, Network_3G varchar(5),GPRS varchar(5), EDGE varchar(5), Bluetooth varchar(5),
Camera varchar(5), Camera_Quality varchar(5) , OS varchar(20), Battery_Life_Hrs numeric ,
constraint fk_ime foreign key(IME_No) references Mobile_Master(IME_No)
);

-- Customer Information table
create table Customer_Info
(
Customer_ID varchar(10) ,
Customer_Name varchar(20),
Address varchar(100),
Mobile numeric(10),
Email varchar(30),constraint pk_customer primary key(Customer_ID));

-- Sales information table
create table Sales_Info
(
SalesId numeric,
Sales_Date date,IME_No varchar(10),Price numeric,Discount numeric,Net_Amount numeric,Customer_ID varchar(10),
constraint fk_sales primary key(SalesId),foreign key(Customer_ID) references Customer_Info(Customer_ID), foreign key(IME_No) references Mobile_Master(IME_No));

 insert into Distributor values('SA110','Mobile_Store','Kolkata',1234567890,
'mobstore@gmail.com');


insert into Distributor values('SA111','Samsung_World','Ranchi',1234567891,
'samworld@ymail.com');

 insert into Distributor values('NO110','Nokia_prio','Delhi',1234567892,'nokprio@gmail.com');

 insert into Distributor values('NO111','Nokia_Dealers','Chandigarh',1234567893,'nokdeal@ymail.com');


 insert into Distributor values('MC110','Micro_World','Bangalore',1234567894,'micwrld@gmail.com');

insert into Distributor values('MC111','Micro_mania','Bokaro',1234567895,'micromania@gmail.com');

insert into Mobile_Master values('SA100010', 'SamsungS2', 'Samsung', '2008-04-12', 2, 25000, 'SA110');

insert into Mobile_Master values('SA100020', 'SamsungS3', 'Samsung', '2010-03-02', 2, 33000, 'SA110');

 insert into Mobile_Master values('SA100030', 'SamsungACE', 'Samsung', '2009-12-25', 2, 15000, 'SA111');

insert into Mobile_Master values('NO100030', 'NokiaLumiaC2', 'Nokia', '2009-11-25', 2, 25000, 'NO111');

 insert into Mobile_Master values('NO100020', 'NokiaLumiaB2', 'Nokia', '2007-10-15', 2, 22000, 'NO110');

 insert into Mobile_Master values('NO100010', 'NokiaAsha', 'Nokia', '2011-9-18', 2, 6500, 'NO111');

 insert into Mobile_Master values('MC100010', 'Ninja37', 'Micromax', '2010-06-08', 2, 7500, 'MC111');

 insert into Mobile_Master values('MC100020', 'Ninja32', 'Micromax', '2011-08-28', 2, 7500, 'MC111');

 insert into Mobile_Master values('MC100030', 'MicromaxQ5', 'Micromax', '2009-03-20', 2, 4500, 'MC110');

insert into Mobile_Specification values('SA100010', '5W10H','100gm','Digital', '5inch', 250, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'Andriod4S', 8);

 insert into Mobile_Specification values('SA100020', '9W15H','100gm','Digital', '10inch', 550, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'Andriod4S', 6);

 insert into Mobile_Specification values('SA100030', '3W5H','50gm','Digital','10inch',200, 16,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 8);

 insert into Mobile_Specification values('NO100030', '8W8H','100gm','Digital', '10inch',500, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'SymbianGT', 10);

 insert into Mobile_Specification values('NO100020', '4W8H','50gm','Digital', '10inch',250, 16,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'SymbianAT', 10);

 insert into Mobile_Specification values('NO100030', '4W8H','70gm','Digital', '5inch',150, 16,'N', 'Y', 'Y', 'Y', 'Y', '2MP', 'Java', 8);

 insert into Mobile_Specification values('MC100010', '6W8H','100gm','Digital', '10inch',250, 32,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 12);

 insert into Mobile_Specification values('MC100020', '8W6H','150gm','Digital', '8inch',150, 16,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 12);

 insert into Mobile_Specification values('MC100030', '4W4H','250gm','Digital', '4inch',100, 8,'N', 'Y', 'Y', 'Y', 'Y', '2MP', 'Java', 12);


 insert into Customer_Info values('MB10010', 'Debarun', 'Kolkata', 9899554411, 'chattdeb@gmail.com');

 insert into Customer_Info values('MB10020', 'Manish', 'Bokaro', 9899554412,'rajman@ymail.com');

insert into Customer_Info values('MB10030', 'Sameer', 'Bokaro', 9899554413,'sameerwaa@gmail.com');

insert into Customer_Info values('MB10040', 'Sumit', 'Deogarh', 9899554414,'rajsumit@ymail.com');

insert into Customer_Info values('MB10050', 'Rahul', 'Patna', 9899554415, 'sharmarahul@gmail.com');


insert into Sales_Info values(1002, '2012-01-11', 'SA100020', 33000, 1000,32000, 'MB10010');

 insert into Sales_Info values(1003, '2012-02-19', 'SA100030', 15000, 200,14800, 'MB10030');

 insert into Sales_Info values(1004, '2012-03-30', 'NO100010', 6500, 100, 6400, 'MB10050');

 insert into Sales_Info values(1005, '2012-01-25', 'MC100010', 7500, 50, 7450, 'MB10020');

 insert into Sales_Info values(1006, '2012-02-11', 'SA100010', 25000, 500,24500, 'MB10020');


select * from distributor;
select * from Mobile_Master;
select * from Mobile_Specification;
select * from Customer_Info;
select * from Sales_Info;

# 1: WAQ to Display the mobile details such as IMENO, Model Name produced by the manufacturer "Nokia".
select IME_NO,Model_name from mobile_master where Manufacturer='nokia';
# 2: WAQ to display IMENO, Model Name,Manufacturer,Camerea Quality of mobiles whose camera quality is 5MP.*/
select m1.ime_no,m1.Model_Name,m1.Manufacturer,m2.camera_quality from mobile_master m1,mobile_specification m2 where m1.ime_no=m2.ime_no and camera_quality='5MP';
# 3: WAQ to  display Model Name,Quantity sold on the date 25-APR-12.*
select model_name,count(*) from sales_info s,mobile_master m where s.IME_No=m.IME_No and Sales_Date=20120125;
# 4: WAQ to display distributor id ,mobile supply details such as mobile model name, quantity supplied in sorted order of distributor id.*/
select m.Distributor_ID,m.MODEL_NAME,COUNT(*) from mobile_master m group by Distributor_id,model_name order by Distributor_ID;
#WAQ to display the IMENO,model name,manufacturer,price and discount of all mobiles regardless of whether the mobile is sold or not.
select m.IME_No,m.Model_Name,m.Manufacturer,m.Price,s.Discount from mobile_master m left outer join sales_info s on m.IME_No=s.IME_No;
#WAQ to display the distributor details such as distributor name,mobile number and email of the model 'Nokia 1100'
select d.distributor_name,d.mobile,d.Email,d.Distributor_ID from distributor d,mobile_master m where d.Distributor_ID=m.Distributor_ID and m.Model_Name='nokiaAsha';
# 7: WAQ to display the Ime No and Model Name of mobiles which are not sold(Hint : use minus operator)
select m.IME_No,m.Model_Name from mobile_master m where m.IME_No not in (select ime_no from sales_info);
# 8: WAQ to display the Ime No and Model Name of mobiles which are sold(Hint : use intersect operator)
select m.ime_no,m.model_name from mobile_master m join sales_info s on m.IME_No=s.IME_No where s.Sales_Date is not null; 
# 9: WAQ to display the ImeNO, Model Name,Manufacturer, Price and NewPrice of all mobiles.
	#(Hint : find new price as 10% of the price with column name "New Price")
select IME_No,model_name,manufacturer,Price,Price+(Price*0.1) "New Price" from mobile_master; 
# 10: WAQ to display mobile model, manufacturer and price for the mobiles having a price range from 8500 to 25300.
SELECT Model_Name,Manufacturer,Price from mobile_master where price between 8500 and 25300;
# 1: WAQ to display the Model Name,Manufacturer, Price , Warranty , Internal memory, memory card capacity,gprs support,bluetooth,camera quality and OS for  the mobile with IME NO "MC1000104" 
select m.ime_no,m.Model_Name,m.Manufacturer,m.Price,m.Warranty_in_Years,ms.Internal_mem_in_MB,ms.Memory_Card_Capacity_GB,ms.gprs,ms.bluetooth,ms.Camera_Quality,ms.OS from mobile_master m,mobile_specification ms where m.ime_no=ms.ime_no and m.IME_No='MC100010';
# 2: WAQ to display IMENO, Model Name,Manufacturer,Price ,GPRS information,Memory card support of mobiles which has GPRS support with memory card  capacity 16GB or above.
select m.IME_No,m.Model_Name,m.Manufacturer,m.Price,ms.GPRS,ms.Memory_Card_Capacity_GB from mobile_master m,mobile_specification ms where m.IME_No=ms.IME_No and ms.gprs='yes' and ms.Memory_Card_Capacity_GB>='16GB';
# 3: WAQ  to display the customer name ,mobile purchase details such as IMENO,Model Name ,Purchase Date,Net amount paid in sorted order of customer   name.
select c.Customer_Name,m.IME_No,m.Model_Name,s.Sales_Date,s.Net_Amount from mobile_master m,customer_info c,sales_info s where c.Customer_ID=s.customer_id and m.ime_no=s.ime_no order by c.Customer_Name;
# 4: WAQ to display the distributor details such as distributor id ,name ,address,contact no who has supplied the maximum number of mobiles.
select d.distributor_id,d.distributor_name,d.address,d.mobile from distributor d inner join mobile_master m on m.distributor_id =d.distributor_id group by m.Manufacturer having count(m.distributor_id)=(select max(t.cd) from (select count(distributor_id)"cd" from mobile_master group by manufacturer)t);
select distributor_id,distributor_name,address,mobile,email from distributor where distributor_id=(select distributor_id from mobile_master having count(distributor_id)=(select max(count(distributor_id)) from mobile_master group by distributor_id ));
 # 5: WAQ to display the IMENO,model name,manufacturer,price and discount of all mobiles regardless of whether the mobile is sold or not.
          #[Hint: If not sold, display discount as "Not Sold"]
select m1.IME_No,m1.Model_Name,m1.Manufacturer,m1.Price,(select'Not Sold' from sales_info s where s.discount not in(select s.discount from sales_info s where discount is null))"discount" from mobile_master m1 left outer join sales_info s on s.IME_No=m1.IME_No; 
select m.ime_no,m.model_name,m.manufacturer,m.price, if(coalesce(s.Discount),discount,'Not Sold')"discount" from mobile_master m left outer join sales_info s on s.ime_no=m.ime_no;
select m.ime_no,m.model_name,m.manufacturer,m1.price,nvl(to_char(m2.discount),'Not Sold') "discount" from mobile_master m1 left outer join  sales_info s on m1.ime_no=s.ime_no;

 # 6: WAQ to display the report containing the sales date and total sales amount of the dates between 20-APR-12 and 25-APR-12. 
	#(Hint : total sales amount column should be displayed as "Total Sales Amount" )
select Sales_Date,net_amount"Total Sales Amount" from sales_info where sales_date between 20120111 and 20120211 group by sales_date;
 # 7: WAQ to display mobile imeno,model name,manufacturer and price of the mobiles which are having the longest battery life.
select m.IME_No,m.model_name,m.Manufacturer,m.Price from mobile_master m where m.IME_No in(select ime_no from mobile_specification where battery_life_hrs=(select max(Battery_Life_Hrs) from mobile_specification));
 # 8: WAQ to display the ImeNO, Model Name,Manufacturer, Price of mobiles having the maximum price
select IME_No,Model_Name,Manufacturer,Price from mobile_master where price in(select max(price) from mobile_master);
 # 9: WAQ to display the customer details such as Customer ID,Customer Name, Address, Total Purchase amount
select c.Customer_ID,c.Customer_Name,c.Address,sum(s.net_amount)"Total Purchase amount"from customer_info c,sales_info s where c.customer_id=s.customer_id;
 # 10: WAQ to display the most costly mobile information such as mobile model, manufacturer and price manufactured by "Samsung".
select Model_Name,Manufacturer,Price from mobile_master where Price in(select max(price) from mobile_master where model_name='samsungs3');
# 1: WAQ to display the customer details such as Customer ID,Customer Name, Address and Total Purchase amount  having the maximum purchase amount.
select c.customer_id,c.Customer_Name,c.Address,s.Net_Amount"Total Purchase amount" from customer_info c,sales_info s where s.net_amount in(select max(s.net_amount)from sales_info s) group by s.net_amount;
 # 2: WAQ to determine whether the mobile with ime no "MC1000105" is been sold out or not  and display the model name,sales status.(Hint: If sold display status as "Sold Out" with column name "Sales Status").
select m.Model_Name,if(coalesce(s.discount),'Sold Out','null')"Sales Status" from mobile_master m,sales_info s where s.ime_no=m.ime_no and m.ime_no='MC100010';  
 # 3: WAQ to display the mobile information such as ime no,model name,manufacturer ,distributor id ,distributor name  and  price supplied  by  the distributor named 'AXA Ltd' .
select m.IME_No,m.Model_Name,m.Manufacturer,d.Distributor_ID,d.distributor_name,m.price from mobile_master m,distributor d where m.distributor_id=d.distributor_id and d.distributor_name='samsung_world';
 # 4: WAQ to display distributor details who supplies mobile with the following speficiations such as 3G Network, Android OS, 5 MP Camera.
select d.Distributor_ID,d.Distributor_Name,d.Address,d.Mobile,d.Email from distributor d,mobile_master m,mobile_specification ms where d.distributor_id=m.distributor_id and m.ime_no=ms.ime_no and ms.network_3G='N' and ms.os like 'JAVA' and ms.camera_quality='2MP'; 
 # 5: WAQ to Display the maximum sold mobile model name and manufacturer 
select m.Model_Name,m.manufacturer from mobile_master m inner join sales_info s on m.IME_No=s.ime_no group by m.model_name having count(s.ime_no)=(select max(t.count) from (select count(ime_no)"count" from sales_info group by (select model_name from mobile_master))t); 
select m1.model_name,m.manufacturer from mobile_master m,(select model_name from (select model_name,count(model_name ))
select manufacturer,model_name, distributor_id from mobile_master group by distributor_id having count(distributor_id)=(select max(t.count) from(select count(distributor_id) as count from mobile_master group by distributor_id)t);


