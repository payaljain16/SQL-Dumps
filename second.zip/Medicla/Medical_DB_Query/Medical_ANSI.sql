
CREATE TABLE PHYSICIAN(
    PHYSICIAN_ID VARCHAR(10) PRIMARY KEY,
    PHYSICIAN_FNAME VARCHAR(20) NOT NULL,
    PHYSICIAN_LNAME VARCHAR(20) NOT NULL,
    ADDRESS VARCHAR(40) NOT NULL,
    SALARY decimal(12, 2 ),
    DEPARTMENT VARCHAR(20) NOT NULL
);

CREATE TABLE SPECIALITY(
    FIELD VARCHAR(20) PRIMARY KEY
);

CREATE TABLE PHYSICIAN_SPECIALITY(
    PHYSICIAN_ID VARCHAR(10),
    FIELD_OF_SPECIALIZATION VARCHAR(20),
    YEARS_OF_SPECIALIZATION integer(3),
    CONSTRAINT PHYID_FK foreign key (PHYSICIAN_ID)
        REFERENCES PHYSICIAN (PHYSICIAN_ID),
    CONSTRAINT FOS_FK foreign key (FIELD_OF_SPECIALIZATION)
        REFERENCES SPECIALITY (FIELD)
);

CREATE TABLE EXPERIENCE_LEVEL(
    LEXP integer(3),
    HEXP integer(3),
    EXPERIENCE VARCHAR(15)
);
 
 
CREATE TABLE NURSE(
    NURSEID VARCHAR(10) PRIMARY KEY,
    NURSENAME VARCHAR(30) NOT NULL,
    SHIFT VARCHAR(10)
);


CREATE TABLE WARD(
WARDNO integer(2) PRIMARY KEY,
    WARDNAME VARCHAR(10) UNIQUE,
    NO_OF_BEDS integer(2),
    TELEPHONE VARCHAR(15),
    NURSE VARCHAR(10),
    CONSTRAINT N_FK foreign key (NURSE)
        REFERENCES NURSE (NURSEID)
);


CREATE TABLE PATIENT(
    PATIENT_NO VARCHAR(10) PRIMARY KEY,
    PATIENT_NAME VARCHAR(25) NOT NULL,
    PHYSICIAN VARCHAR(10),
    WARD_NO integer(2),
    DATE_IN DATE,
    CONSTRAINT P_FK foreign key (PHYSICIAN)
        REFERENCES PHYSICIAN (PHYSICIAN_ID),
    CONSTRAINT W_FK foreign key (ward_no)
        REFERENCES WARD (WARDNO)
);


CREATE TABLE INVOICE(
    INVOICE_NO VARCHAR(10) PRIMARY KEY,
    SERVICE_TYPE VARCHAR(15),
    AMOUNT decimal(15, 2 ),
    PATIENT_NO VARCHAR(10),
    PHYSICIAN_ID VARCHAR(10),
    CONSTRAINT PID_FK foreign key (physician_id)
        REFERENCES PHYSICIAN (PHYSICIAN_ID),
    CONSTRAINT PNO_FK foreign key (patient_no)
        REFERENCES PATIENT (PATIENT_NO)
);

select 
    *
from
    physician ;

insert into physician values ('PHY001','John','Doyle','23 Alexander Bell Drive',60000,'Pediatrics');
insert into physician values('PHY002','Edna','Frank','53 Elmo Ave, #320',45000,'General Practice');
insert into physician values('PHY003','Joseph','Raj','21 Foxcroft Lane',77000,'Psychiatry');
insert into physician values('PHY004','Doris','Marena','219 Liverpool Lane',50000,'Gynecology');
insert into physician values('PHY005','Anton','Dunn','5063 Rye Lane',62000,'Psychiatry');
insert into physician values('PHY006','Mitterand','Clark','66 Brookway. #32',80000,'Pediatrics');

insert into speciality values('Cardiology');

insert into speciality values('Pulmonology');

insert into speciality values('Neurology');

insert into speciality values('Endocrinology');

insert into speciality values('Genetics');

insert into speciality values('Pediatrics');


insert into physician_speciality values('PHY001','Pediatrics',10);

insert into physician_speciality values('PHY001','Genetics',6);

insert into physician_speciality values ('PHY002','Cardiology',15);

insert into physician_speciality values('PHY003','Endocrinology',12);

insert into physician_speciality values ('PHY004','Genetics',12);

insert into physician_speciality values('PHY004','Pediatrics',12);


INSERT INTO EXPERIENCE_LEVEL VALUES (1,5,'BEGINNER');

INSERT INTO EXPERIENCE_LEVEL VALUES(6,15,'INTERMEDIATE');

INSERT INTO EXPERIENCE_LEVEL VALUES(16,30,'EXPERT');

INSERT INTO NURSE VALUES ('NN01','Joey','DAY')
;
INSERT INTO NURSE VALUES ('NN02','Jim','NIGHT')
;
INSERT INTO NURSE VALUES ('NN03','Cooper','DAY')
;
INSERT INTO NURSE VALUES ('NN04','Sheila','DAY')
;
INSERT INTO NURSE VALUES ('NN05','Greta','NIGHT')
;
INSERT INTO NURSE VALUES ('NN06','Bill','DAY')
;
INSERT INTO NURSE VALUES ('NN07','Graham','DAY')
;
INSERT INTO NURSE VALUES ('NN08','Julie','NIGHT');

INSERT INTO WARD VALUES (1,'Blue',20,'(301)-676 3432','NN01')
;
INSERT INTO WARD VALUES (2,'Red',25,'(301)-673 2332','NN02')
;
INSERT INTO WARD VALUES (3,'Orange',22,'(301)-693 2211','NN04')
;
INSERT INTO WARD VALUES (4,'Grey',22,'(301)-445 2124','NN03')
;
INSERT INTO WARD VALUES (5,'Green',24,'(301)-445 2123','NN05');


INSERT INTO PATIENT VALUES ('CS0012','Ryan 

Rogers','PHY003',1,'2012-10-20')
;
INSERT INTO PATIENT VALUES ('CS0014','Fred 

Fuller','PHY003',4,'2012-12-16')
;
INSERT INTO PATIENT VALUES ('CS0020','Madeline 

Moon','PHY001',1,'2013-01-19')
;
INSERT INTO PATIENT VALUES ('CS0021','Ray 

Capriati','PHY003',4,'2012-09-21')
;
INSERT INTO PATIENT VALUES ('CS0022','Sue 

Shepherd','PHY002',4,'2012-10-23')
;
INSERT INTO PATIENT VALUES ('CS0033','Wendy 

Silk','PHY001',2,'2013-01-03')
;
INSERT INTO PATIENT VALUES ('CS0035','Gabriela 

Glean','PHY002',2,'2013-01-12')
;
INSERT INTO PATIENT VALUES ('CS0036','June 

Fredrick','PHY001',null,'2012-11-30')
;


INSERT INTO INVOICE VALUES ('DMV001','IN-

PATIENT',36000,'CS0022','PHY002');

INSERT INTO INVOICE VALUES ('DMV002','OUT-

PATIENT',150,'CS0036','PHY001');

INSERT INTO INVOICE VALUES ('DMV003','IN-

PATIENT',12000,'CS0033','PHY001');

commit;