/*Average Questions:
Problem # 1:
Write a query to display the Department_Name, Department_Location whose number of employees are 
more than or equal to 4
*/
select d.department_name,d.department_location ,count(p.department_id)
from pms_manager_details p
inner join
pms_department_details d
on
p.department_id=d.department_id
group by p.department_id
having count(p.department_id)>=4;
/*Problem # 2:
Find the Persons with a Job which has the highest average salary. In select list we have MANAGER_ID, 
MANAGER_NAME, JOB, and SALARY.
*/
select MANAGER_ID,MANAGER_NAME,JOB,SALARY from pms_manager_details
where salary>(select avg(salary) from pms_manager_details);

/*Problem # 3:
List the employees who earn more than their own department’s average salary and display them in 
Department_ID order. In select list we have MANAGER_ID, MANAGER_NAME, JOB, SALARY, and DEPARTMENT_ID.*/

SELECT MANAGER_ID,MANAGER_NAME,JOB,SALARY,DEPARTMENT_ID
FROM 
PMS_MANAGER_DETAILS P
WHERE
SALARY>(SELECT AVG(SALARY) FROM PMS_MANAGER_DETAILS WHERE DEPARTMENT_ID=P.DEPARTMENT_ID)
ORDER BY DEPARTMENT_ID;

/*
Problem # 4:
Display the Product details that are ends with MILK. In select list we have to display PRODUCT_ID, 
PRODUCT_NAME, UNIT_ID, and UNIT_WEIGHT.
Hint: PMS_PRODUCT Table Alias as P
PMS_PRODUCT_UNIT Table Alias as U
PMS_UNIT_DETAILS Table Alias as D*/
SELECT P.PRODUCT_ID,P.PRODUCT_NAME,U.UNIT_ID,D.UNIT_WEIGHT 
FROM PMS_PRODUCT P
INNER JOIN 
PMS_PRODUCT_UNIT U
ON P.PRODUCT_ID=U.PRODUCT_ID
INNER JOIN
PMS_UNIT_DETAILS D
ON U.UNIT_ID=D.UNIT_ID
WHERE P.PRODUCT_NAME LIKE '%MILK';
/*
Problem # 5:
Display the Product Name’s along with their possible packing details in the order of Weight.
In select list we have to display PRODUCT_NAME, UNIT_NAME, TOTAL_PIECES, and UNIT_WEIGHT.
Hint: PMS_PRODUCT Table Alias as P
PMS_PRODUCT_UNIT Table Alias as U
PMS_UNIT_DETAILS Table Alias as D
*/
SELECT P.PRODUCT_NAME,D.UNIT_NAME,D.TOTAL_PIECES,D.UNIT_WEIGHT 
FROM PMS_PRODUCT P
INNER JOIN 
PMS_PRODUCT_UNIT U
ON P.PRODUCT_ID=U.PRODUCT_ID
INNER JOIN
PMS_UNIT_DETAILS D
ON U.UNIT_ID=D.UNIT_ID
order by d.unit_weight;

/*
Problem # 6:
Display the product_id and sum of quantity whose available status is ‘yes’. 
And sum of quantity greater than 1500.
Hint: TOTAL_QUANTITY is an Alias name used in the select query.*/
SELECT PRODUCT_ID,SUM(QUANTITY)
FROM
PMS_MANUFACTURING
WHERE AVAILABILITY='YES'
GROUP BY PRODUCT_ID
HAVING SUM(QUANTITY)>1500;
/*
Problem # 7:
Display Product_ID, Product_Name, Department_ID and the number of varieties of units available as on ’15-dec-12’.
Hint: NUMBER_VARIETIES as an Alias name for Count field in select query.
PMS_MANUFACTURING Table Alias as M
PMS_PRODUCT Table Alias as P
*/

SELECT P.PRODUCT_ID,P.PRODUCT_NAME,P.DEPARTMENT_ID,count(distinct(m.unit_id)) NUMBER_VARIETIES
FROM PMS_MANUFACTURING M
INNER JOIN
PMS_PRODUCT P
ON M.PRODUCT_ID=P.PRODUCT_ID
WHERE M.AVAILABILITY='YES'
AND date_format(M.PRODUCT_EXPIRY_DATE,'%d-%b-%y')='15-Dec-12'
GROUP BY M.PRODUCT_ID;

/*
Problem # 8:
List the employees earning more than the average salary of employees based out of ONGOLE. 
In select list we have MANAGER_ID and MANAGER_NAME*/
select * from
pms_manufacturing;
/*
Problem#9:
List the MANAGER’s who have salary higher than that of the department with highest number of employees. 
In select list we have MANAGER_ID, MANAGER_NAME, JOB and SALARY.
*/

select * from pms_manager_details
where job='MANAGER'
and salary>
(
    select max(salary) from pms_manager_details
    group by department_id
    having count(department_id)=
    (
        select max(did) from
        (
        select count(department_id) did from pms_manager_details
        group by department_id
        ) t1
    )
);


select * from pms_manager_details;
/*
Problem#10:
List the departments which does not have any employees. 
In select query we have DEPARTMENT_ID,DEPARTMENT_NAME
*/

select department_id,department_name from pms_department_details
where department_id not in(select department_id from pms_manager_details);