use pms;

select M.Manager_ID, M.Manager_Name, M.Job,B.Manager_Name as 'Boss name'
from PMS_MANAGER_DETAILS M join PMS_MANAGER_DETAILS B
on M.Boss_Code=B.Manager_Id;

select Manager_Id,Manager_Name,Job,Salary,Commission,Department_Id
from PMS_MANAGER_DETAILS
order by Salary desc limit 1,1;

select Manager_Id,Manager_Name,Job,Salary
from PMS_MANAGER_DETAILS
where Manager_Name like '_A%' and Salary>(select Salary
									from PMS_MANAGER_DETAILS
									where Manager_Name like 'V%');

select Manager_Id,Manager_Name,Job,round((Salary+((7.5*Salary)/100))*12) as YEARLY_SALARY
from PMS_MANAGER_DETAILS;

select M.Manufacture_Id,P.Product_Name,M.Unit_Id,M.Quantity,M.Product_Manufacture_Date,M.Product_Expiry_Date
from PMS_MANUFACTURING M join PMS_PRODUCT P
on P.Product_Id=M.Product_Id;

select Quantity,sum(Quantity),count(Quantity) as SUM_OF_QUANTITY
from PMS_MANUFACTURING
group by Quantity;

select P.Product_Id,M.Product_Expiry_Date,P.Product_Name
from PMS_PRODUCT P join PMS_MANUFACTURING M
on P.Product_Id=M.Product_Id
where M.Product_Expiry_Date like '2012-12-15' and availability like 'yes';

select P.Product_Id,count(P.Product_Id) as COUNT_PRODUCT,M.Product_Expiry_Date
from PMS_PRODUCT P join PMS_MANUFACTURING M
on P.Product_Id=M.Product_Id
where Product_Expiry_Date like '2012-12-15' and availability like 'no';

select Manager_ID,Manager_Name,Job
from PMS_MANAGER_DETAILS
where Salary>
        (Select avg(salary)
         from PMS_MANAGER_DETAILS
		where Job like 'Manager') and job not like 'Manager';


select Manager_ID,Manager_Name,Department_Id
from PMS_MANAGER_DETAILS
where Salary>20000 
order by Department_Id;

