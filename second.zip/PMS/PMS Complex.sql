/*Complex Questions:
Problem # 1:
Display the details of manager who is drawing the 7th highest salary among all the other managers. 
In select list we have MANAGER_ID,MANAGER_NAME,JOB,SALARY and DEPARTMENT_ID*/

select * from
pms_manager_details
order by salary desc
limit 6,1;

/*
Problem # 2:
Write a query to find the list of all the sub ordinates whose salary is greater than the 
respective boss salary. In select list we have S.MANAGER_ID,S.MANAGER_NAME,S.JOB,S.SALARY,
S.DEPARTMENT_ID,B.MANAGER_ID,B.MANAGER_NAME,B.SALARY
Hint: PMS_MANAGER_DETAILS Table Alias as S
PMS_MANAGER_DETAILS Table Alias as B
*/

select S.MANAGER_ID,S.MANAGER_NAME,S.JOB,S.SALARY,S.DEPARTMENT_ID,B.MANAGER_ID,B.MANAGER_NAME,B.SALARY 
from
pms_manager_details S
inner join
pms_manager_details B
on
s.boss_code=b.manager_id
where s.salary>b.salary;

/*
Problem # 3:
Find the number of batches manufactured greater than 5 in each month
Displaying the Month name and Number of batches.
Hint: MONTH AS AN ALIAS NAME FOR MONTH NAME
NUMBER_BATCHES AS AN ALIAS NAME FOR COUNT FIELD IN THE SELECT QUERY
*/
SELECT COUNT(UNIT_ID) FROM PMS_MANUFACTURING;

/*
Problem # 4:
Display the PRODUCT_ID, PRODUCT_NAME, and DEPARTMENT_ID which is manufactured maximum 
with respect to sum of quantity.
*/
SELECT M.PRODUCT_ID,P.PRODUCT_NAME,P.DEPARTMENT_ID
FROM PMS_MANUFACTURING M
INNER JOIN
PMS_PRODUCT P
ON M.PRODUCT_ID=P.PRODUCT_ID
GROUP BY PRODUCT_ID
HAVING SUM(QUANTITY)=
(
    SELECT MAX(QTY) FROM
    (
        SELECT SUM(QUANTITY) QTY FROM
        PMS_MANUFACTURING
        GROUP BY PRODUCT_ID
    )T1
);
/*
Problem # 5:
Find the maximum quantity manufactured with respect to each product and display the product id, 
product name and Quantity from each product.
Hint: PMS_MANUFACTURING Table Alias as M
PMS_PRODUCT Table Alias as PP
*/
SELECT M.PRODUCT_ID,PP.PRODUCT_NAME,MAX(M.QUANTITY) FROM PMS_MANUFACTURING M
INNER JOIN
PMS_PRODUCT PP
ON M.PRODUCT_ID=PP.PRODUCT_ID
GROUP BY M.PRODUCT_ID;
