use pms;

select D.Department_Name,D.Department_Location
from PMS_DEPARTMENT_DETAILS D join PMS_MANAGER_DETAILS M
on D.Department_Id=M.Department_Id
group by D.Department_Id
having count(M.Manager_Id)>=4;

select Manager_Id,Manager_Name,Job,Salary
from PMS_MANAGER_DETAILS
group by Job
having Salary >avg(Salary);

select Manager_Id,Manager_Name,Job,Salary
from PMS_MANAGER_DETAILS
where Salary in (select distinct avg(Salary) 
from pms_manager_details 
group by Job) 
order by salary desc limit 0,1;



select Manager_Id,Manager_Name,Job,Salary,Department_Id 
from pms_manager_details
where salary>
(select distinct avg(salary) as s 
from pms_manager_details)
group by job;

select P.Product_Id,P.Product_Name,U.Unit_Id,U.Unit_Weight
from PMS_PRODUCT P join PMS_PRODUCT_UNIT PU join PMS_UNIT_DETAILS U
on P.Product_Id=PU.Product_Id and PU.Unit_Id=U.Unit_Id
where P.Product_Name like '%Milk';

select P.Product_Id,P.Product_Name,U.Total_Pieces,U.Unit_Weight
from PMS_PRODUCT P join PMS_PRODUCT_UNIT PU join PMS_UNIT_DETAILS U
on P.Product_Id=PU.Product_Id and PU.Unit_Id=U.Unit_Id
order by U.Unit_Weight;

select P.Product_Id,sum(M.Quantity) as Total_Quantity
from PMS_PRODUCT P join PMS_Manufacturing M
on P.Product_Id=M.Product_Id
where M.Availability='Yes'
group by P.Product_Id
having sum(M.Quantity)>1500;

select P.Product_ID,P.Product_Name,P.Department_ID,count(M.Unit_Weight) as NUMBER_VARIETIES
from PMS_PRODUCT P join PMS_Manufacturing M 
on P.Product_Id=M.Product_Id 
where M.Availability='Yes'
group by M.Unit_Id;

select Manager_Id,Manager_Name
from PMS_MANAGER_DETAILS
where Salary>(Select avg(Salary)
				from PMS_MANAGER_DETAILS P join PMS_DEPARTMENT_DETAILS D
on D.Department_Id=P.Department_Id
where D.Department_location='ongole');

select Manager_Id,Manager_Name,Job,Salary
from PMS_MANAGER_DETAILS
where Salary>
(select max(Salary) 
from pms_manager_details
group by Department_Id
having count(Department_Id));

select Department_Id,Department_Name
from PMS_DEPARTMENT_DETAILS
where Department_Id not in(Select Department_Id
from PMS_MANAGER_DETAILS);



