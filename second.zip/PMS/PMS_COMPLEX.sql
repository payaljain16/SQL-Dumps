use PMS;

select Manager_Id,Manager_Name,Job,Salary,Department_Id 
from pms_manager_details
order by Salary desc;

select Manager_Id,Manager_Name,Job,Salary,Department_Id 
from pms_manager_details
order by Salary desc limit 6,1;

select Unit_ID,count(Unit_Id) as NUMBER_BATCHES,Date_Format(Product_Manufacture_Date,'%M') as Month_Name
from PMS_MANUFACTURING
group by UNIT_ID
having count(Unit_Id)>5;

select P.Product_ID,P.Product_Name,P.Department_ID,sum(M.Quantity)
from PMS_PRODUCT P join PMS_MANUFACTURING M
on P.Product_ID=M.Product_ID
group by sum(Quantity)
where Product_Id

select P.Product_ID,P.Product_Name,P.Department_ID,sum(M.Quantity)
from PMS_PRODUCT P join PMS_MANUFACTURING M
on P.Product_ID=M.Product_ID,
(Select max(a.P)from PMS_MANUFACTURING,(Select sum(Prodcuct_Id) as 'P'
from PMS_MANUFACTURING)a
group by sum(Quantity);


select P.Product_ID,P.Product_Name,P.Department_ID,sum(M.Quantity)
from PMS_PRODUCT P join PMS_MANUFACTURING M
on P.Product_ID=M.Product_ID,
(Select max(a.Q)from PMS_MANUFACTURING,(Select Product_Id,sum(Quantity) as 'Q'
from PMS_MANUFACTURING
group by Quantity)a)b;
group by b;

select P.Product_ID,P.Product_Name,P.Department_ID,sum(M.Quantity)
from PMS_PRODUCT P join PMS_MANUFACTURING M
on P.Product_ID=M.Product_ID
group by M.Quantity;
Select  as 'Q'
from PMS_MANUFACTURING)