/*Simple Questions:
Problem # 1:
List the Managers and their respective Boss Names. In select list we have Manager_ID, 
Manager_Name, Job, and Boss_Name.
Hint: PMS_MANAGER_DETAILS alias as Manager
PMS_MANAGER_DETAILS alias as Boss
Boss_Name as an alias in the select query.*/
select * from pms_manager_details;
select * from pms_department_details;
select * from pms_manufacturing;
select * from pms_product;
select * from pms_product_unit;
select * from pms_unit_details;

select Manager.Manager_Name,Boss.Manager_Name Boss_Name
from pms_manager_details Manager
left outer join
pms_manager_details Boss
on Manager.Boss_code=Boss.Manager_ID;


/*Problem # 2:
Find the 2nd Highest Salary Earner of all the Managers. 
In select list we have Manager_ID,Manager_Name,Job,Salary,Commission,Department_ID
*/

select Manager_ID,ManageR_Name,Job,Salary,Commission,Department_ID
from pms_manager_details
where salary=
(
    select max(salary) from pms_manager_details
    where salary < (select max(salary) from pms_manager_details where Job='Manager')
          and
          Job='Manager'
);

/*Problem # 3:
Find out the Employees whose name has letter ‘A’ in the 2nd position & are 
earning more than the salary whose name starts with ‘V’. In select list we have 
MANAGER_ID, MANAGER_NAME, JOB, and SALARY.*/
select *
from pms_manager_details
where Manager_Name like '_A%'
and salary>(select salary from pms_manager_details where 
manager_name like 'V%');
/*
Add 7.5% of salary as performance bonus for each employee and display the net yearly salary of each employee. 
(Do not update the database.). 
In select list we have MANAGER_ID, MANAGER_NAME, JOB, and YEARLY_SALARY.*/

Problem # 4:
Add 7.5% of salary as performance bonus for each employee and display the net yearly salary of 
each employee. (Do not update the database.). In select list we have MANAGER_ID, MANAGER_NAME, JOB, 
and YEARLY_SALARY.
YEARLY_SALARY as an alias for the expression used in select query.*/
select Manager_ID,ManageR_Name,Job,(salary+(salary*0.075))*12 YEARLY_SALARY
from 
pms_manager_details;

/*
Problem # 5:
Display the Manufactured products details that are belong to ‘GHEE SECTION’. In select list we have 
MANFATURE_ID, PRODUCT_NAME, UNIT_ID, QUANTITY, PRODUCT_MANFACTURE_DATE, and PRODUCT_EXPIRY_DATE.
Hint: PMS_MANUFACTURING TABLE ALIAS AS M
PMS_PRODUCT TABLE ALIAS AS P*/
select * from pms_manager_details;
select * from pms_department_details;
select * from pms_manufacturing;
select * from pms_product;
select * from pms_product_unit;
select * from pms_unit_details;

select m.manfature_ID,p.product_name,m.unit_id,m.quantity,
m.product_manfacture_date,m.product_expiry_date from 
pms_manufacturing m
inner join
pms_product p
on m.product_id=p.product_id
where p.department_id=20;
/*
Problem # 6:
FIND SUM OF QUANTITY WITH RESPECT TO EACH QUANTITY.*/

select sum(quantity)
from pms_manufacturing
group by quantity;
/*
Problem # 7:
Find the list of products which are available as on ’15-DEC-12’.*/

select * from
pms_manufacturing  
where date_format(product_expiry_date,'%d-%b-%y') = '15-Dec-12'
and availability='YES';

/*
Problem # 8:
Find the list of products along with their count which are not available as on ’15-DEC-12’. 
In select query COUNT_PRODUCT as an alias for count field.*/
select count(*) COUNT_PRODUCT from
pms_manufacturing  
where date_format(product_expiry_date,'%d-%b-%y') = '15-Dec-12'
and availability='NO';
/*
Problem # 9:
Find the employees with higher salary than the average salary of ‘MANAGER’ and those 
are all not MANAGER’S. In select list we have Manager_ID, Manager_Name and their Job details.
*/
select Manager_ID,Manager_Name,Job from pms_manager_details
where salary>(select avg(salary) from pms_manager_details where Job='MANAGER')
and Job <> 'MANAGER';
/*
Problem # 10:
Display the manager details who are drawing the salary more than 20000 Rs/-. 
And we need to display the manager name in proper case and order by department wise. 
In select list we have Manager_ID, Manager_Name and Department_ID.*/
select Manager_ID,Concat(Upper(left(Manager_Name,1)),Lower(substring(Manager_Name,2))) Manager_Name
,Department_ID 
from pms_manager_details
where salary>20000
order by department_id;