-- Distributor Info table
create table Distributor(Distributor_ID varchar(10) ,
Distributor_Name varchar(20),Address varchar(100),
Mobile int(10),Email varchar(30),constraint 
pk_distributor primary key(Distributor_ID));


-- Mobile master table
create table Mobile_Master(IME_No varchar(10), 
Model_Name varchar(20), Manufacturer varchar(20), 
Date_Of_Manufac date,Warranty_in_Years int, 
Price int, Distributor_ID varchar(10),
constraint pk_ime primary key(IME_No),
foreign key(Distributor_ID) references 
Distributor(Distributor_ID));


-- Mobile specification table
create table Mobile_Specification(IME_No varchar(10), 
Dimension varchar(20), Weight varchar(20),Display_Type 
varchar(20), Display_Size varchar(20),Internal_mem_in_MB int
,Memory_Card_Capacity_GB int, Network_3G varchar(5),
GPRS varchar(5), EDGE varchar(5), Bluetooth varchar(5),
Camera varchar(5), Camera_Quality varchar(5) , 
OS varchar(20), Battery_Life_Hrs int,constraint 
fk_ime foreign key(IME_No) references Mobile_Master(IME_No));


-- Customer Information table
create table Customer_Info1(Customer_ID varchar(10),
Customer_Name varchar(20),Address varchar(100),Mobile int(10),
Email varchar(30),constraint pk_customer primary key(Customer_ID));


-- Sales information table
create table Sales_Info1(SalesId int,Sales_Date date,IME_No 
varchar(10),Price int,Discount int,Net_Amount int,Customer_ID
varchar(10),constraint fk_sales primary key(SalesId),
foreign key(Customer_ID)references Customer_Info1(Customer_ID),
foreign key(IME_No)references Mobile_Master(IME_No));



 insert into Distributor values('SA110','Mobile_Store','Kolkata',1234567890,
'mobstore@gmail.com');

 insert into Distributor values('SA111','Samsung_World','Ranchi',1234567891,
'samworld@ymail.com');

 insert into Distributor values('NO110','Nokia_prio','Delhi',1234567892,
'nokprio@gmail.com');

 insert into Distributor values('NO111','Nokia_Dealers','Chandigarh',1234567893,
'nokdeal@ymail.com');

 insert into Distributor values('MC110','Micro_World','Bangalore',1234567894,
'micwrld@gmail.com');

insert into Distributor values('MC111','Micro_mania','Bokaro',1234567895,
'micromania@gmail.com');



insert into Mobile_Master values('SA100010', 'SamsungS2', 'Samsung', 
'2012-04-21', 2, 25000, 'SA110');

insert into Mobile_Master values('SA100020', 'SamsungS3', 
'Samsung', '2012-04-23', 2, 33000, 'SA110');

 insert into Mobile_Master values('SA100030', 'SamsungACE', 
'Samsung', '2010-05-13', 2, 15000, 'SA111');

insert into Mobile_Master values('NO100030', 'NokiaLumiaC2', 
'Nokia', '2010-07-15', 2, 25000, 'NO111');

 insert into Mobile_Master values('NO100020', 'NokiaLumiaB2',
 'Nokia', '2012-04-25', 2, 22000, 'NO110');

 insert into Mobile_Master values('NO100010', 'NokiaAsha', 
'Nokia', '2011-06-21', 2, 6500, 'NO111');

 insert into Mobile_Master values('MC100010', 'Ninja37', 
'Micromax', '2012-06-22', 2, 7500, 'MC111');

 insert into Mobile_Master values('MC100020', 'Ninja32', 
'Micromax', '2011-09-28', 2, 7500, 'MC111');

 insert into Mobile_Master values('MC100030', 'MicromaxQ5',
 'Micromax', '2012-08-19', 2, 4500, 'MC110');



 insert into Mobile_Specification values('SA100010', '5W10H','100gm','Digital', 
'5inch', 250, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'Andriod4S', 8);
 insert into Mobile_Specification values('SA100020', '9W15H','100gm','Digital',
 '10inch', 550, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'Andriod4S', 6);
 insert into Mobile_Specification values('SA100030', '3W5H','50gm','Digital',
'10inch',200, 16,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 8);
 insert into Mobile_Specification values('NO100030', '8W8H','100gm','Digital', 
'10inch',500, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'SymbianGT', 10);
 insert into Mobile_Specification values('NO100020', '4W8H','50gm','Digital', 
'10inch',250, 16,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'SymbianAT', 10);
 insert into Mobile_Specification values('NO100030', '4W8H','70gm','Digital', 
'5inch',150, 16,'N', 'Y', 'Y', 'Y', 'Y', '2MP', 'Java', 8);
 insert into Mobile_Specification values('MC100010', '6W8H','100gm','Digital', 
'10inch',250, 32,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 12);
 insert into Mobile_Specification values('MC100020', '8W6H','150gm','Digital', 
'8inch',150, 16,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 12);
 insert into Mobile_Specification values('MC100030', '4W4H','250gm','Digital', 
'4inch',100, 8,'N', 'Y', 'Y', 'Y', 'Y', '2MP', 'Java', 12);

 insert into Customer_Info1 values('MB10010','Debarun','Kolkata',989955441, 
'chattdeb@gmail.com');
 insert into Customer_Info1 values('MB10020', 'Manish', 
'Bokaro', 989955441,'rajman@ymail.com');
insert into Customer_Info1 values('MB10030', 'Sameer', 
'Bokaro', 989955441,'sameerwaa@gmail.com');
insert into Customer_Info1 values('MB10040', 'Sumit', 
'Deogarh', 989955441,'rajsumit@ymail.com');
insert into Customer_Info1 values('MB10050', 'Rahul', 
'Patna', 989955441, 'sharmarahul@gmail.com');

 insert into Sales_Info1 values(1002, '2012-01-11', 'SA100020', 33000, 1000,
32000, 'MB10010');
 insert into Sales_Info1 values(1003, '2012-02-12', 'SA100030',
 15000, 200,14800, 'MB10030');
 insert into Sales_Info1 values(1004, '2012-03-30', 'NO100010',
 6500, 100, 6400, 'MB10050');
 insert into Sales_Info1 values(1005, '2012-01-25', 'MC100010',
 7500, 50, 7450, 'MB10020');
 insert into Sales_Info1 values(1007, '2012-04-11', 'SA100010',
 25000, 500,2500, 'MB10020');

select *from mobile_master;
select *from distributor;
select *from customer_info1; 
select *from sales_info1;
select *from mobile_specification;


-- 1 WAQ to Display the mobile 
-- details such as IMENO, Model Name produced by the manufacturer "Nokia".
select ime_no,model_name from mobile_master 
where manufacturer='nokia';

-- 2 WAQ to display IMENO, Model Name,Manufacturer,Camerea Quality of 
-- mobiles whose camera quality is 5MP.
select m.ime_no,m.model_name,m.manufacturer,ms.camera_quality 
from mobile_master m  join mobile_specification ms on(m.ime_no=
ms.ime_no) where ms.camera_quality='5mp';

-- 3 WAQ to  display Model Name,Quantity sold on the date 25-APR-12.
select model_name,count(ime_no) from mobile_master where sales_date='23-apr-12'
group by model_name;

-- 4 WAQ to display distributor id ,mobile supply details such as 
-- mobile model name, quantity supplied in sorted order of distributor id.
select d.distributor_id,m.model_name,count(model_name)quanity
from distributor d join mobile_master m on d.distributor_id=
m.distributor_id group by m.distributor_id order by 
m.distributor_id;

-- 5 WAQ to display the IMENO,model name,manufacturer,price and discount 
-- of all mobiles regardless of whether the mobile is sold or not.
select m.ime_no,m.manufacturer,m.model_name,s.price,s.discount
from mobile_master m left join sales_info1 s
on m.ime_no=s.ime_no;

-- 6 WAQ to display the distributor details such as distributor name,
-- mobile number and email of the model 'Nokia 1100'.
select d.distributor_name,d.mobile,d.email from distributor d
join mobile_master m on d.distributor_id=m.distributor_id 
where m.model_name='ninja37';

-- 7 WAQ to display the Ime No and Model Name of mobiles which are not
-- sold(Hint : use minus operator)
select m.ime_no,m.model_name from mobile_master m join 
sales_info1 s on m.ime_no=s.ime_no;

-- 8 WAQ to display the Ime No and Model Name of mobiles which are
-- sold(Hint : use intersect operator)
select m.ime_no,m.model_name from mobile_master m where 
m.ime_no
not in(select s.ime_no from sales_info1 s);

-- 9 WAQ to display the ImeNO, Model Name,Manufacturer, Price and NewPrice 
-- of all mobiles.(Hint : find new price as 10% of the price with column name
-- "New Price")

select ime_no,model_name,price,price+(price*10/100)newprice
from mobile_master;

-- 10 WAQ to display mobile model, manufacturer and price for 
-- the mobiles having a price range from 8500 to 25300
select model_name,manufacturer,price from mobile_master 
where price between '8000' and '23000';




-- 1 average 



-- WAQ to display the Model Name,Manufacturer, Price , Warranty ,
-- Internal memory, memory card capacity,gprs support,bluetooth,
-- camera quality and OS for  the mobile with IME NO "MC1000104" .
select m.ime_no,m.model_name,m.manufacturer,m.price,
m.warranty_in_years,
ms.gprs,ms.camera_quality,ms.memory_card_capacity_gb,ms.os,
ms.bluetooth from mobile_master m join mobile_specification
ms on m.ime_no=ms.ime_no where m.ime_no='mc100020';

-- 2 WAQ to display IMENO, Model Name,Manufacturer,Price ,GPRS 
-- information,Memory card 
-- support of mobiles which has GPRS support with memory card  capacity 
-- 16GB or above.
select m.ime_no,m.model_name,m.manufacturer,m.price,
ms.gprs,ms.memory_card_capacity_gb from mobile_master m join mobile_specification
ms on m.ime_no=ms.ime_no where ms.gprs='y' and 
ms.memory_card_capacity_gb>16;

-- 3 WAQ  to display the customer name ,mobile purchase accessible
-- such as IMENO,Model Name ,Purchase Date,Net amount paid in sorted 
-- order of customer   name.
select c.customer_name,m.model_name,s.price,s.net_amount from
customer_info1 c join mobile_master m join sales_info1 s
on s.ime_no=m.ime_no and c.customer_id=s.customer_id
order by c.customer_name;

-- 4 WAQ to display the distributor details such as 
-- distributor id ,name ,address,contact no who has supplied 
-- the maximum number of mobiles.
select d.distributor_id,d.distributor_name,d.address,d.mobile
from distributor d join mobile_master m where d.distributor_id=
m.distributor_id and m.distributor_id in(select m.distributor_id
from mobile_master m group by m.distributor_id
having count(m.distributor_id)>=all(select count(m.distributor_id) from
mobile_master m group by m.distributor_id))group by 
m.distributor_id;

-- 5 WAQ to display the IMENO,model name,manufacturer,price and 
-- discount of all mobiles regardless of whether the mobile is sold or not.
select m.ime_no,m.model_name,m.manufacturer,m.price,
case when m.ime_no not in(select s.ime_no from sales_info1 s)
then 'not sold' else s.discount end as discount1 from
mobile_master m left join sales_info1 s on m.ime_no=s.ime_no;



-- 6 : WAQ to display the report containing the sales date and 
-- total sales amount of the dates between 20-APR-12 and 25-APR-12. 
select sales_date,sum(net_amount)netamount from sales_info1 s
where sales_date between '2012-01-11' and '2012-02-21'
group by sales_date;

-- 7: WAQ to display mobile imeno,model name,manufacturer
-- and price of the mobiles which are having the longest battery life.
select m.ime_no,m.model_name,m.manufacturer,m.price from
mobile_master m join mobile_specification ms on m.ime_no=ms.ime_no
 where ms.battery_life_hrs=(select max(ms.battery_life_hrs) 
from mobile_specification ms) group by ms.ime_no;

-- 8 WAQ to display the ImeNO, Model Name,Manufacturer,
-- Price of mobiles having the maximum price.
select c.customer_id,c.customer_name,c.address,sum(ms.net_amount)
from customer_info1 c join sales_info1 ms on c.customer_id=
ms.customer_id group by ms.customer_id;

-- 9 WAQ to display the most costly mobile information
--  such as mobile model, manufacturer and price manufactured by "Samsung".
select model_name,manufacturer,max(price)price from 
mobile_master where manufacturer='samsung';

-- 10 : WAQ to display the customer details such as Customer ID,Customer
-- Name, Address, Total Purchase amount.


-- 1 : WAQ to display the customer details such as Customer ID,Customer
-- Name, Address and Total Purchase amount  having the maximum purchase amount
select c.customer_id,c.customer_name,c.address,sum(s.net_amount)
from customer_info1 c join sales_info1 s on c.customer_id=
s.customer_id where s.customer_id=(select s.customer_id from
sales_info1 s group by s.customer_id having sum(s.net_amount)>=all
(select sum(s.net_amount) from
sales_info1 s group by s.customer_id))group by s.customer_id;

-- 2 WAQ to determine whether the mobile with ime no "MC1000105" 
-- is been sold out or not  and display the model name,sales status.
-- (Hint: If sold display status as "Sold Out" with column name "Sales Status").
select m.model_name, case when s.ime_no='mc100010' then 'sold_out'
end as sstaus from mobile_master m join sales_info1 s
on m.ime_no=s.ime_no  where m.ime_no='mc100010';
-- or
select m.model_name,(select 'sold_out' from sales_info1 s where
s.ime_no='mc100010')sstatus from mobile_master m where 
m.ime_no='mc100010';

-- 3 WAQ to display the mobile information such as ime no,model name,manufacturer ,
-- distributor id ,distributor name  and  price supplied  by  the
-- distributor named 'AXA Ltd' .
select m.ime_no,m.model_name,m.price,d.distributor_id,
d.distributor_name from mobile_master m join distributor d
on m.distributor_id=d.distributor_id 
where d.distributor_name='micro_mania';

-- 4 : WAQ to display distributor details who supplies mobile with the following 
-- speficiations such as 3G Network, Android OS, 5 MP Camera
select d.distributor_id,d.distributor_name from distributor d
join mobile_specification s join mobile_master m 
on d.distributor_id=m.distributor_id and m.ime_no=s.ime_no
where s.network_3g='y' and s.camera_quality='5mp' and
s.os like '%andriod%' group by m.distributor_id;
-- or
select d.distributor_id,d.distributor_name,d.address,d.mobile 
from distributor d where d.distributor_id IN (select 
m.distributor_id from mobile_master m where m.ime_no IN 
(select s.ime_no from mobile_specification s where s.network_3g='Y'
 and s.os LIKE '%Android%'  and s.camera_quality='5MP' ));

-- 5 WAQ to Display the maximum sold mobile model name and manufacturer 
select m.model_name,m.manufacturer from mobile_master m join
sales_info1 s on m.ime_no=s.ime_no where m.ime_no in(select
s.ime_no from sales_info1 s group by s.ime_no having 
count(s.ime_no)>=all(select count(s.ime_no) from sales_info1 s
group by s.ime_no))group by s.ime_no;


