-- 1)	Display productid,prodname whose uni price between 200 and 400.
Select product_id,product_name
From  bab_order_products
Where unit_price between 200 and 400;

-- count the no of products in each category as alias name �NOOFPRODUCT� 
-- and category colun

select category,count(product_id) as CATEGORY_NAME
from  bab_order_products
group by category;

/*-- Display prodid,ordered,category and their sales price. Sales should be product of �Quantity and
-- Unit price,.sales should be in year of 2013.
*/ 
Select p.product_id,p.category,o.order_id,(o.quantity*o.unit_price)
From bab_order_products p,bab_order_details o,bab_orders b
Where p.product_id=o.product_id and o.order_id=b.order_id 
and order_date like '%2013%';


/*Display products belongs to Chennai(city). List should contains customerid,custonername,Billing
address,city*/

select c.customer_id,c.customer_name,c.billing_address,c.city
from bab_customer c, bab_products p,bab_order_details o,bab_order b
where p.product_id=o.product_id and o.order_id=b.order_id  
and c.customer_id=b.customer_id and c.city like 'chennai'
group by product_id;


/*Display cutomerid, name belongs to �food� category.*/

Select c.customer_id
from bab_customer c, bab_products p,bab_order_details o,bab_order b
where p.product_id=o.product_id and o.order_id=b.order_id  
and c.customer_id=b.customer_id and p.category='food';


/*Display sales in month from payment amount. Month name jan, feb, march

Ex.  Sales month   sales

       Jan                    2016.32

      Feb                    4440

      March               54545
*/
Select date_format(payment_date,'%'),sum(payment_amount)
From bab_payments
Group by monthname(payment_date);

/*Display the empid, name who has maximum quantity.
Hint- If quantity order are multiple time then consider total quantity  i.e sum(quantity) group by ordered
*/
Select c.employee_id
from bab_employee c, bab_products p,bab_order_details o,bab_order b
where p.product_id=o.product_id and o.order_id=b.order_id  and c.employee_id=b.employee_id
group by c.employee_id
having sum(o.quantity)=
(Select max(ct)
From (Select sum(o.quantity) as ct
from bab_employee c, bab_products p,bab_order_details o,bab_order b
where p.product_id=o.product_id and o.order_id=b.order_id  
and c.employee_id=b.employee_id
group by c.employee_id)t
)


/*Display salestax with % symbol
i.e. concat(�salestax�,�%�)
       	*/
select sales_tax,concat(sales_tax,"%") 'sale%'
from bab_order_details;





/*Display year, Quartername,sale_price  for the year 2013 only. Sales price is sum of unit price.
     Ex.        Date                   Quarter_year          Sales_price    
             11/08/2013                        Q4                    23233
*/

		When Month(o.order_date) between 1 and 3 then �Q1�
		When Month(o.order_date) between 4 and 6 then �Q2�
		When Month(o.order_date) between 7 and 9 then �Q3�
		Else �Q4� as Quarter_year,sum(p.unit_price) as Sales_price
from bab_products p,bab_order_details o,bab_order b
where p.product_id=o.product_id and o.order_id=b.order_id
group by Quarter_year;

