-- Complex

select manager_id,manager_name,job,salary,department_id from pms_manager_details
where salary=(select salary from pms_manager_details group by salary order by salary desc limit 6,1);

select s.manager_id,s.manager_name,s.job,s.Salary,s.Department_id,
b.manager_id as Boss_id,b.manager_name as Boss_name,b.salary as Boss_salary from pms_manager_details s
left outer join pms_manager_details b 
on s.boss_code=b.manager_id
where s.salary > b.salary;


select a.product_id,a.product_name,department_id,Quantity from pms_manufacturing a
join pms_product b on
a.product_id=b.product_id


select a.product_id,b.product_name,max(a.quantity) Quantity from pms_manufacturing a
join pms_product b on
a.product_id=b.product_id
group by a.product_id;