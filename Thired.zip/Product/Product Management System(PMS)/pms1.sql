create database pms;

use pms;

CREATE TABLE PMS_DEPARTMENT_DETAILS
(DEPARTMENT_ID INT(2)PRIMARY KEY,DEPARTMENT_NAME VARCHAR(30)NOT NULL,
DEPARTMENT_LOCATION VARCHAR(30)NOT NULL,DEPARTMENT_EXTENSION INT(3) NOT NULL);
-- PMS_MANAGER_DETAILS TABLE

CREATE TABLE PMS_MANAGER_DETAILS
(Manager_ID INT(5) PRIMARY KEY,Manager_Name VARCHAR(30) NOT NULL,
Job VARCHAR(30) NOT NULL,Boss_Code INT(5),Salary BIGINT NOT NULL,
Commission INT(5),DEPARTMENT_ID INT(2));
-- PMS_UNIT_DETAILS TABLE

CREATE TABLE PMS_UNIT_DETAILS
(UNIT_ID VARCHAR(2) PRIMARY KEY,UNIT_NAME VARCHAR(30) NOT NULL,
PIECE_WEIGHT VARCHAR(15) NOT NULL,TOTAL_PIECES INT(3) NOT NULL,
UNIT_WEIGHT INT NOT NULL);
-- PMS_PRODUCT TABLE

CREATE TABLE PMS_PRODUCT
(PRODUCT_ID VARCHAR(5) PRIMARY KEY,PRODUCT_NAME VARCHAR(30) NOT NULL,
DEPARTMENT_ID INT(2));
-- PMS_PRODUCT_UNIT

CREATE TABLE PMS_PRODUCT_UNIT
(PRODUCT_ID VARCHAR(5),UNIT_ID VARCHAR(2));
-- PMS_MANUFACTURING TABLE

CREATE TABLE PMS_MANUFACTURING
(MANFATURE_ID VARCHAR(5) PRIMARY KEY,PRODUCT_ID VARCHAR(5) NOT NULL,
UNIT_ID VARCHAR(5) NOT NULL,QUANTITY INT(7) NOT NULL,AVAILABILITY VARCHAR(3) NOT NULL,
PRODUCT_MANFACTURE_DATE DATE NOT NULL,PRODUCT_EXPIRY_DATE DATE NOT NULL);
-- Tables created successfully

-- PMS DML STATEMENTS
-- INSERT INTO PMS_DEPARTMENT_DETAILS TABLE
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(10,'MIS','HYDERABAD_ZONE_1',121);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(20,'GHEE SECTION','ONGOLE',122);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(30,'PROCESSING SECTION','RAJAMUNDRY',123);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(40,'BI_PRODUCTS SECTION','SECUNDERABAD',124);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(50,'DISPATCH SECTION','HYDERABAD_ZONE_2',125);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(60,'CUSTOMER CARE SECTION','HYDERABAD_ZONE_2',126);
-- INSERT INTO PMS_MANAGER_DETAILS TABLE
INSERT INTO PMS_MANAGER_DETAILS VALUES(7711,'BLAKE','GENERAL MANAGER',NULL,25000,2500,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7722,'LARANCE','DEPUTY GENERAL MANAGER',7711,28000,1500,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7733,'GATES','MANAGER',7722,26750,500,20);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7744,'CALRK','MANAGER',7722,22000,1000,30);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7755,'VINCY','MANAGER',7722,17500,0,40);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7766,'GALE','MANAGER',7722,16500,0,50);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7770,'NANCY','ASSISTANT MANAGER',7733,30000,500,20);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7771,'GOUD','ASSISTANT MANAGER',7744,23000,750,30);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7772,'NAIDU','ASSISTANT MANAGER',7755,18500,0,40);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7773,'RAO','ASSISTANT MANAGER',7766,15000,3000,50);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7774,'RAJU','ASSISTANT MANAGER',7722,21050,2000,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7775,'REDDY','ASSISTANT MANAGER',7722,28500,0,10);
-- INSERT INTO PMS_UNIT_DETAILS TABLE
INSERT INTO PMS_UNIT_DETAILS VALUES('C1','CARTON','235 ML/GMS',20,5);
INSERT INTO PMS_UNIT_DETAILS VALUES('M1','MIN_BOX','25 GMS',20,.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('M2','MAX_BOX','25 GMS',40,1);
INSERT INTO PMS_UNIT_DETAILS VALUES('C2','CAN','19.7 KGS',1,20);
INSERT INTO PMS_UNIT_DETAILS VALUES('T1','TIN','30 GMS',50,1.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('P1','PACK','980 ML',1,1);
INSERT INTO PMS_UNIT_DETAILS VALUES('P2','HALF_PACK','480 ML/GMS',1,0.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('P3','CHOTA_PACK','235 ML/GMS',1,0.25);
-- INSERT INTO PMS_PRODUCT TABLE
INSERT INTO PMS_PRODUCT VALUES('P001','MIXED GHEE',20);
INSERT INTO PMS_PRODUCT VALUES('P002','PANNER',20);
INSERT INTO PMS_PRODUCT VALUES('P003','COOKING BUTTER',20);
INSERT INTO PMS_PRODUCT VALUES('P004','RASAGULLA',40);
INSERT INTO PMS_PRODUCT VALUES('P005','CURD',40);
INSERT INTO PMS_PRODUCT VALUES('P006','DIET MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P007','TONNED MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P008','FAMILY MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P009','STANDERED MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P010','WHOLE MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P011','BUTTER MILK',40);
INSERT INTO PMS_PRODUCT VALUES('P012','DOODH PEDA',40);
INSERT INTO PMS_PRODUCT VALUES('P013','MILK SHAKE',40);
-- INSERT INTO PMS_PRODUCT_UNIT TABLE
INSERT INTO PMS_PRODUCT_UNIT VALUES('P001','C2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P001','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P001','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P001','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P002','C1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P002','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P002','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P002','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P006','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P006','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P006','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P007','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P007','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P007','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P008','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P008','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P008','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P009','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P009','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P009','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P010','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P010','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P010','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P003','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P003','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P004','T1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P005','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P011','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P012','M1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P012','M2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P013','C1');
-- INSERT INTO PMS_MANUFACTURING TABLE
INSERT INTO PMS_MANUFACTURING VALUES('M001','P001','C2',100,'YES','2012-08-15','2012-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M002','P001','P2',500,'YES','2012-08-10','2012-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M003','P001','P3',250,'YES','2012-08-10','2012-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M004','P001','P1',300,'NO','2012-08-15','2012-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M005','P002','C1',190,'YES','2012-08-05','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M006','P002','P1',500,'YES','2012-08-05','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M007','P002','P2',250,'YES','2012-08-05','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M008','P002','P3',500,'YES','2012-08-05','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M009','P006','P1',4500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M010','P006','P2',7500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M011','P006','P3',10000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M012','P007','P1',4000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M013','P007','P2',3000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M014','P007','P3',2500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M015','P008','P1',7000,'NO','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M016','P008','P2',3500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M017','P008','P3',4500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M018','P009','P1',1500,'NO','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M019','P009','P2',2500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M020','P009','P3',1000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M021','P010','P1',10000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M022','P010','P2',25000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M023','P010','P3',12500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M024','P003','P2',2400,'YES','2012-08-10','2012-10-10');
INSERT INTO PMS_MANUFACTURING VALUES('M025','P003','P3',3210,'NO','2012-08-10','2012-10-10');
INSERT INTO PMS_MANUFACTURING VALUES('M026','P004','T1',750,'YES','2012-08-10','2012-12-10');
INSERT INTO PMS_MANUFACTURING VALUES('M027','P005','P3',10000,'YES','2012-08-15','2012-08-17');
INSERT INTO PMS_MANUFACTURING VALUES('M028','P011','P3',27500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M029','P012','M1',2750,'YES','2012-08-15','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M030','P012','M2',1850,'NO','2012-08-15','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M031','P013','C1',1300,'YES','2012-08-10','2012-08-11');

#EXERCISE

-- SIMPLE

-- q1
SELECT S.Manager_ID,S.Manager_Name,S.Job,B.Manager_Name as Boss_Name
FROM pms_manager_details s inner join pms_manager_details B 
ON S.Boss_Code = B.Manager_ID;

-- q2
select Manager_ID,Manager_Name,Job,Salary,Commission,Department_ID
from pms_manager_details
where Salary= (select distinct Salary from pms_manager_details order by salary desc limit 1,1);

-- q3
select Manager_ID,Manager_Name,Job,(Salary*12) as YEARLY_SALARY
from pms_manager_details
where Manager_Name like '_A%' and Salary > (select Salary from pms_manager_details where Manager_Name like 'V%');

-- q4
select Manager_ID,Manager_Name,Job,(Salary+(Salary*0.075))*12 as YEARLY_SALARY
from pms_manager_details;

-- q5
select M.MANFATURE_ID,P.PRODUCT_NAME,M.UNIT_ID,M.QUANTITY,M.PRODUCT_MANFACTURE_DATE,M.PRODUCT_EXPIRY_DATE
from pms_manufacturing M join pms_product P join pms_department_details D
on M.PRODUCT_ID=P.PRODUCT_ID and P.DEPARTMENT_ID=D.DEPARTMENT_ID 
where D.DEPARTMENT_NAME='GHEE SECTION';

-- q6???????????????????????????????????????
select QUANTITY,sum(quantity)
from pms_manufacturing 
group by quantity 
order by QUANTITY;

-- Q7???????????????????????????????????????
select b.PRODUCT_ID
FROM pms_product A ,pms_manufacturing B
where A.PRODUCT_ID=B.PRODUCT_ID 
AND PRODUCT_MANFACTURE_DATE<='2012-12-15' 
and PRODUCT_EXPIRY_DATE>='2012-12-15' and AVAILABILITY='YES';

-- q8
select PRODUCT_ID,count(PRODUCT_ID)
from pms_manufacturing
where PRODUCT_MANFACTURE_DATE<='2012-12-15' 
and PRODUCT_EXPIRY_DATE>='2012-12-15' and AVAILABILITY='NO';

-- q9
select Manager_ID,Manager_Name,Job
from pms_manager_Details
where Job not like 'MANAGER' and salary > 
(select avg(Salary) from pms_manager_details where Job = 'MANAGER');

-- q10
select Manager_ID,concat(substring(Manager_Name,1,1),lower(substring(Manager_Name,2))) as MANAGER_NAME,Department_ID
from pms_manager_details
where Salary>20000
order by Department_ID;



#Average

-- q1
select d.DEPARTMENT_NAME,d.DEPARTMENT_LOCATION
FROM pms_department_details d join pms_manager_details m 
on m.DEPARTMENT_ID=d.DEPARTMENT_ID
group by m.department_id
having count(m.department_id)>=4; 

-- q2
select Manager_ID,Manager_Name,Job,Salary
from pms_manager_details
where Job = (select job
from pms_manager_details
group by job
order by avg(salary) desc limit 0,1);

-- q3
select MANAGER_ID,MANAGER_NAME,JOB,SALARY,a.DEPARTMENT_ID
from pms_manager_details a,(select department_id,avg(salary) as avgsal from pms_manager_details
group by department_id) b
where a.department_id=b.department_id and salary > avgsal;

-- q4
select u.product_id,product_name,u.unit_id,unit_weight
from pms_product p,pms_product_unit u,pms_unit_details d
where u.product_id=p.product_id and u.unit_id=d.unit_id and product_name like '% MILK';

-- q5?????????????????????????????????????????????????
select PRODUCT_NAME, UNIT_NAME, TOTAL_PIECES,UNIT_WEIGHT
from pms_product p,pms_product_unit u,pms_unit_details d
where u.product_id=p.product_id and u.unit_id=d.unit_id
order by unit_weight;

-- q6
select product_id,sum(quantity) as TOTAL_QUANTITY
from pms_manufacturing
where availability='YES'
group by product_id
having sum(quantity)>1500;

-- q7
select A.PRODUCT_ID,A.PRODUCT_NAME,A.DEPARTMENT_ID,count(B.UNIT_ID) as Number_of_Varities_of_Units
FROM pms_product A ,pms_manufacturing B
where A.PRODUCT_ID=B.PRODUCT_ID 
AND PRODUCT_MANFACTURE_DATE<='2012-12-15' 
and PRODUCT_EXPIRY_DATE>='2012-12-15' and AVAILABILITY='YES';

-- q8????????????????????????????????????????????
select Manager_id,Manager_name
from pms_manager_details
where salary >
(select avg(salary)
from pms_manager_details m,pms_department_details d
where m.department_id=d.department_id and department_location='ONGOLE');

-- q9?????????????????????????????????????????????
select manager_id,manager_name,job,salary
from pms_manager_details
where salary > 
(select max(salary)
from pms_manager_details m,pms_department_details d
where m.department_id=d.department_id
group by m.department_id
order by m.department_id limit 0,1);

#sumanth soln doubt
select manager_id,manager_name from pms_manager_details 
where salary in
	(select max(salary) as salary from pms_manager_details where department_id in
		(select department_id from pms_manager_details 
			group by department_id 
			having count(manager_id) in
			(select max(c.coun) from
				(select count(manager_id) as coun
					from pms_manager_details
					group by department_id
				)c
				
			)
			
		)
	);

#to find manager getting max sal in respective dept
select Manager_id,Department_id,salary
from pms_manager_details
where salary in (select max(salary) from pms_manager_details group by department_id); 

#to select dept having max manager
select distinct department_id,count(department_id)
from pms_manager_details
group by department_id
order by count(department_id) desc limit 0,1;

-- q10
select d.department_id,department_name
from pms_department_details d
where d.department_id not in
(select m.department_id
from pms_department_details d,pms_manager_details m
where d.department_id=m.department_id);

#alternate soln sumanth
select department_name,department_id
from pms_department_details
where department_id not in (select department_id from pms_manager_details);

#COMPLEX-------------------------------

-- q1
SELECT Manager_ID,Manager_Name,Job,Salary,Department_ID
FROM pms_manager_details
where salary = (select distinct Salary from pms_manager_details order by Salary desc limit 6,1);

-- q2
SELECT S.Manager_ID,S.Manager_Name,S.Job,S.Salary,S.Department_ID,B.Manager_ID,B.Manager_Name,B.Job,B.Salary
FROM pms_manager_details s inner join pms_manager_details B 
ON S.Boss_Code = B.Manager_ID
where S.Salary>B.Salary;

-- q3(((((((((((((((

#sumanth soln doubt
select count(product_id),extract(month from product_manfacture_date) as months
from pms_manufacturing
group by product_id;

-- q4??????????????????????????
select distinct p.PRODUCT_ID, p.PRODUCT_NAME,DEPARTMENT_ID
from pms_product p,pms_manufacturing m
where p.product_id=m.product_id and p.product_id =
(select m.product_id
from pms_manufacturing m
group by m.product_id
order by sum(quantity) desc limit 0,1);

#alternate soln sumanth
select product_id,product_name,department_id from pms_product where product_id in
(select product_id from pms_manufacturing group by product_id having sum(quantity) in
	(select max(c.quantity) from
		(select sum(quantity) as quantity
		from pms_manufacturing
		group by product_id
		)c
	)
);

-- q5???????????????????????????
select m.product_id,product_name,max(quantity) 
from pms_product p,pms_manufacturing m 
where p.product_id=m.product_id 
group by m.product_id;

#alternate soln sumanth
select a.product_id,a.product_name,max(b.quantity) as quantity
from pms_product a inner join pms_manufacturing b
on a.product_id=b.product_id
group by product_id;


-- extras
  select concat(
substring(job,1,1),
'.',
case 
when ISNULL(boss_code) then salary
else concat(boss_code,' ',salary) 
end) as name 
from pms_manager_details;