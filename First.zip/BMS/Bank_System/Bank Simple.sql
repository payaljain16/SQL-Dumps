/*Problem #1:
Write a query to display the customer number , firstname, customer’s date of birth .
 Display in a sorted order of date of birth year and within that sort by firstname.*/
 select custid,fname,dob from customer
 order by dob,fname;
/*Problem #2:
Write a query to display customer’s number, first name and middle name. 
The customer’s who don’t have middle name, for them display the last name. 
Give the alias name as Cust_Name.*/
select custid,concat(fname,' ',ifnull(mname,ltname)) Cust_Name
from customer;
/*Problem#3:
Write a query to display account number, customer’s number, customer’s firstname,lastname,account 
opening date.*/
select a.acnumber,c.custid,c.fname,c.ltname,a.aod from
customer c
inner join
account a
on c.custid=a.custid;

/*Problem # 4:
Write a query to display the number of customer’s from Delhi. Give the count an alias 
name of Cust_Count.*/
select count(*) Cust_Count from customer
group by city
having city='Delhi';
/*Problem # 5:
Write a query to display  the customer number, customer firstname,account number 
for the customer’s whose accounts were created after 15th of any month.*/
select c.custid,c.fname,a.acnumber,a.aod from
customer c
inner join
account a
on c.custid=a.custid
where date_format(a.aod,'%d')>15;
/*Problem # 6:
Write a query to display the female customers firstname, city and account number 
who are not into business, service or studies.*/
select c.fname,c.city,a.acnumber
from customer c
inner join
account a 
on c.custid=a.custid
where c.occupation not in('Service','Student','Business');
/*Problem # 7:
Write a query to display city name and count of branches in that city. 
Give the count of branches an alias name of Count_Branch.*/
 
select bcity,count(bname) Count_Branch
from branch
group by bcity;
 
/*Problem # 8:
Write a query to display account id, customer’s firstname, customer’s lastname for the
customer’s whose account is Active.*/
select acnumber,c.fname,c.ltname
from 
customer c
inner join
account a
on c.custid=a.custid
where a.astatus='Active';

/*Problem # 9:
Write a query to display the customer’s number, customer’s firstname, branch id and loan 
amount for people who have taken loans.*/
select c.custid,c.fname,l.bid,l.loan_amount
from 
customer c
inner join
loan l
on c.custid=l.custid;

/*Problem # 10:
Write a query to display customer number, customer name, account number where the account 
status is terminated.*/
select c.custid,c.fname,a.acnumber
from 
customer c
inner join
account a
on c.custid=a.custid
where a.astatus='Terminated';