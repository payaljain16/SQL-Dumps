/*Problem#1:
Write a query to display  the total number of  withdrawals and total number 
of deposits being done by customer whose registration is C00001.
 Give the count an alias name of Trans_Count.*/
 
select count(transaction_type) Trans_Count
from 
customer c
inner join
account a
on 
c.custid=a.custid
inner join
trandetails t
on
t.acnumber=a.acnumber
where
c.custid='C00001'
group by transaction_type;

/*Problem # 2:
Write a query to display the customer’s number, customer’s firstname, customer’s city and branch 
city where the city of the customer and city of the branch is different.*/
select c.custid,c.fname,c.city,b.bcity
from customer c
inner join
account a
on 
c.custid=a.custid
inner join
branch b
on a.bid=b.bid
where b.bcity<>c.city;



/*Problem # 3:
Write a query to display the customer number, customer firstname, customer lastname who
has taken loan from more then 1 bank.*/

select distinct(c.custid),c.fname,c.ltname
from customer  c
inner join
loan l
on c.custid=l.custid
where c.custid in
(
    select distinct(id) from
        (
            select count(custid),custid id
            from loan
            group by custid
            having count(custid)>1
        ) t1
);

/*Problem # 4:
Write a query to display the number of client who have asked for loans but they don’t have 
any account in the bank though they are registered customers. 
Give the count an alias name of Count.*/

select distinct(count(*)) Count from loan
where custid not in
(select custid from account);
/*Problem # 5:
Write a query to display account id, and total amount deposited by each account holder 
( Including the opening balance ). 
Give the total amount deposited an alias name of Deposit_Amount.*/
select t.acnumber,sum(t.transaction_amount)+sum(distinct(a.opening_balance))
from trandetails t
inner join
account a
on t.acnumber=a.acnumber
where 
transaction_type='Deposit'
group by t.acnumber;


/*Problem # 6:
Write a query to the count the number of customers who have registration 
but no account in the bank.
Give the alias name as Count_Customer.*/
select count(*) Count_Customer
from customer c
where custid not in (select custid from account);

/*Problem # 7:
Write a query to display citywise, branchwise count of accounts. 
For the branch where we don’t have any records display 0.*/
SELECT B.BID,COUNT(A.ACNUMBER),B.BCITY FROM BRANCH B
LEFT OUTER JOIN
ACCOUNT A 
ON A.BID=B.BID
GROUP BY B.BID,B.BCITY;

SELECT B.BCITY,COUNT(A.BID) FROM
BRANCH B
INNER JOIN
ACCOUNT A
ON B.BID=A.BID
GROUP BY B.BCITY;

SELECT B.BID,COUNT(A.ACNUMBER),B1.BCITY,COUNT(B1.BID)
FROM BRANCH B
LEFT OUTER JOIN
ACCOUNT A 
ON A.BID=B.BID
LEFT OUTER JOIN
BRANCH B1
ON B1.BID=A.BID
GROUP BY B.BID,BCITY;


/*Problem # 8:
Write  a query to display the customer’s firstname who have more then 1 account.*/
select c.custid,c.fname from customer c
inner join
account a
on c.custid=a.custid
group by a.custid
having count(a.custid)>1;

select * from account;
/*Problem # 9:
Write a query to display the customer’s firstname who have multiple accounts atleast in 2 banks.*/
select c.fname /*,count(distinct(a.bid)),a.custid*/
from account a 
inner join
customer c
on 
a.custid=c.custid
group by a.custid
having count(distinct(a.bid))>=2;

 
/*Problem # 10: 
Display the customer number, customer name, account number and number of transactions  
being made by a customer. Give the alias name for number of transactions as Count_Trans*/
select a.custid,c.fname,a.acnumber,count(t.tnumber) Count_Trans
from trandetails t
inner join
account a 
on a.acnumber=t.acnumber
inner join
customer c 
on a.custid=c.custid
group by a.custid;