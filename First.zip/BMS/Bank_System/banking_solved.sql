-- --- easy ----
-- 1
select custid,fname,dob from customer order by extract(year from dob),fname;

-- 2
select custid,concat(fname,' ',coalesce(mname,ltname)) cust_name from customer;


-- 3
select c.custid,c.fname,c.ltname,a.acnumber,a.aod from account a join customer c on a.custid=c.custid;


-- 4
select count(custid) cust_account from customer where city='delhi' group by city;


-- 5
select c.custid,c.fname,a.acnumber from customer c 
join account a on a.custid=c.custid where extract(day from a.aod)>15;

select extract(day from aod) from account;


-- 6
select c.fname,c.city,a.acnumber from account a join
customer c on a.custid=c.custid where c.occupation not in('business' , 'service' , 'student');


-- 7
select bcity,count(bname)  count_branch from branch group by bcity;

-- 8
select a.acnumber,c.fname,c.ltname from customer c 
join account a on c.custid=a.custid where a.astatus='Active';

-- 9
select c.fname,l.custid,l.bid,l.loan_amount from customer c 
join loan l on l.custid=c.custid;

-- 10
select a.acnumber,a.custid,c.fname from customer c
join account a on a.custid=c.custid where a.astatus='terminated';

-- -----hard-----

-- 1
select acnumber from trandetails group by acnumber having count(transaction_type)
>=ALL(select count(transaction_type) from trandetails group by acnumber);


-- 2
select bname,bcity from branch where bid=
(select bid from account group by bid having count(custid)>=
ALL(select count(custid) from account group by bid));


-- 3
select ((select sum(transaction_amount) 
from trandetails where transaction_type='deposit' and acnumber='A00001' group by acnumber)-
(select sum(transaction_amount) from trandetails where transaction_type='withdrawal' 
and acnumber='A00001' group by acnumber)+(select a.acnumber,a.opening_balance from account a join trandetails t on a.acnumber=t.acnumber)) net_amount ; 

-- 4
select a-b cal,k.acnumber from 
(select sum(transaction_amount) a,acnumber 
from trandetails where transaction_type='deposit'  group by acnumber) m, 
(select sum(transaction_amount) b ,acnumber from trandetails where transaction_type='withdrawal' 
group by acnumber) k  where m.acnumber=k.acnumber having cal<0;


-- 5
select custid,fname,ltname from customer where custid in (select custid from loan having sum(loan_amount)
>=ALL(select sum(loan_amount) from loan group by custid));


SELECT c.custid,c.fname,c.ltname from customer c join loan l using(custid) group by c.custid 
having sum(l.loan_amount)>=all(select sum(loan_amount) from loan group by custid having count(bid)>=2 );

-- ------average-----


-- 1
select acnumber from trandetails group by acnumber having count(transaction_type) 
<=ALL(select count(transaction_type) from trandetails group by acnumber);


-- 2

select c.custid,c.fname,

-- 3

select c.custid,c.fname,c.ltname from customer c 
join loan l on c.custid=l.custid group by l.custid having count(l.custid) 
>=ALL(select count(bid) from loan group by custid);

-- 4
select count(custid) count from loan where bid not in
(select a.bid from account a join loan l on a.custid=l.custid where a.bid=l.bid) ;


-- 5
select t.acnumber,sum(t.transaction_amount)+a.opening_balance Deposit_Amount 
from trandetails t join account a on a.acnumber=t.acnumber 
where transaction_type='Deposit' group by acnumber;


-- 6
select count(custid) count from customer where custid  not in(select custid from account);


-- 7
select count(a.custid) count from account a right join branch b on a.bid=b.bid group by b.bcity,b.bid;


-- 8
select custid,fname from customer where custid in
(select custid from account group by custid having count(acnumber) in 
(select count(acnumber) from account   group by custid having count(acnumber)>1));


-- 9
select custid,fname from customer where custid in
(select custid from account group by custid having count(acnumber) in 
(select count(acnumber) from account   group by custid having count(acnumber)>1)) and custid in
(select custid from account group by custid having count(bid) in 
(select count(bid) from account   group by custid having count(bid)>=2));


-- 10
COMPLEX-------4------ select dd.acnumber,deposit,withdrawal,dd.opening_balance,(deposit-withdrawal+dd.opening_balance)as balance 
from 
(select sum(transaction_amount)as Deposit,b.Opening_balance,a.acnumber from trandetails a,account b
where b.acnumber=a.acnumber and transaction_type='Deposit' group by a.acnumber)dd,
(select sum(transaction_amount)as Withdrawal,a.acnumber  from trandetails a,account b
where b.acnumber=a.acnumber and transaction_type='Withdrawal' group by a.acnumber)ww
where dd.acnumber=ww.acnumber group by dd.acnumber;
