use casestudy4;

select * from patients;
-- 1

select name from patients where lastVisitDate='2012-09-15';

select * from patients where lastVisitDate between '2012-09-15' and current_date order by lastVisitDate;

-- 2

select name,dateOfBirth,round(datediff(current_date,dateOfBirth)/365.25) as Age from patients where year(dateOfBirth)='2011' order by day(dateOfBirth),month(dateOfBirth);

-- 3

select name from patients where day(dateOfBirth)=day(current_date) and month(dateOfBirth)=month(current_date);

-- 4

select name,round(datediff(current_date,dateOfBirth)/365) as Age from patients order by Age;

-- 5

select name,lastVisitDate from patients having datediff(current_date,lastVisitDate)>60;

-- 6

select name,dateOfBirth from patients having round(datediff(current_date,dateOfBirth)/365)<=18;