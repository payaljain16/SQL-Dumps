use casestudy2;

-- 1

select cname from clients where cid in (select cid from branches where bloc='CA');

-- 2
select bdesc from branches where cid in (select cid from clients where cname ='Rabbit Foods Inc');

-- 3

select cid from clients where cname ='Sharp Eyes Detective Agency';

select bid from branches where cid in (select cid from clients where cname ='Sharp Eyes Detective Agency');

select sid from branches_services where bid = (select bid from branches where cid in (select cid from clients where cname ='Sharp Eyes Detective Agency'));

select sname from services where sid in (select sid from branches_services where bid = (select bid from branches where cid in (select cid from clients where cname ='Sharp Eyes Detective Agency')));

-- 4
select cid from branches group by cid having count(bid)=2;
select cname from clients where cid in (select cid from branches group by cid having count(bid)=2);

-- 5

select sid from services having max(sfee);

select bid from branches_services where sid in (select sid from services having max(sfee));

select cid from branches where bid in (select bid from branches_services where sid in (select sid from services having max(sfee)));

select cname from clients where cid in (select cid from branches where bid in (select bid from branches_services where sid in (select sid from services having max(sfee))));

-- 6
select bid from branches_services group by bid having count(sid) > (select (count(sid)/2) from services); 


select a.bdesc, a.bid, b.cname
	from branches a, clients b, (select bid from branches_services group by bid having count(sid) > (select (count(sid)/2) from services)) c
	where a.bid=c.bid and b.cid=a.cid;

-- 7

select bid from branches_services group by bid having count(sid) = (select count(sid) from services);

select bdesc,bloc from branches where bid in (select bid from branches_services group by bid having count(sid) = (select count(sid) from services));

-- 8 

select a.cname 
	from clients a,branches b, branches_services c
	where a.cid=b.cid and b.bid=c.bid 
	group by (a.cid) having count(c.sid) = (select count(*) from services);

-- 9

select cname from clients where cid not in (select cid from branches);



-- 10
-- a
select sid from services where sname ='Recruitment';

select bid from branches_services where sid in (select sid from services where sname ='Recruitment');

select bdesc from branches where bid in (select bid from branches_services where sid in (select sid from services where sname ='Recruitment'));
 
-- b 
select a.bdesc 
	from branches a, branches_services b, services c
	where c.sname='Recruitment' and b.sid=c.sid and a.bid=b.bid;

-- 11 
-- a
select cid from clients where cname='JV Real Estate';

select bloc from branches where cid in (select cid from clients where cname='JV Real Estate') and bdesc='Corporate HQ';

select bdesc from branches where bloc =(select bloc from branches where cid in (select cid from clients where cname='JV Real Estate') and bdesc='Corporate HQ');

-- b 

select a.bdesc
	from branches a inner join branches b
	on a.bloc=b.bloc
	inner join clients c on b.cid=c.cid 
	where c.cname='JV Real Estate' and b.bdesc='Corporate HQ';
