select b.book_code,b.publication,b.price,s.supplier_name from 
lms_book_details b
inner join lms_suppliers_details s on
b.supplier_id=s.supplier_id join lms_book_issue i on i.book_code=b.book_code 
group by i.book_code having count(i.book_code)=
(select max(t.count) from (select count(book_code) as 
count from lms_book_issue group by book_code)t);
select b1.book_code,b.publication,b.price,s.supplier_name from lms_book_details b,lms_suppliers_details s,
(select b1.book_code from (select book_code,count(book_code)"c" from lms_book_issue group by book_code)b1 where b1.c in
(select max(i.c) from (select book_code,count(book_code)"c" from lms_book_issue group by book_code)i))b1 
where b1.book_code=b.book_code and s.supplier_id=b.supplier_id;
# 9:Write a query to display the date on which the maximum numbers of books were issued and the number of books issued with alias name “NOOFBOOKS”.
select date_issue,count(book_code)"NOOFBOOKS" from lms_book_issue group by date_issue having count(book_code)=(select max(t.c) from(select count(book_code)"c" from lms_book_issue group by date_issue)t);
#1Write a query to display the book code, book title and supplier name of the supplier who has supplied maximum number of books. For example, if “ABC Store” supplied 3 books, “LM Store” has supplied 2 books and “XYZ Store” has supplied 1 book. So “ABC Store” has supplied maximum number of books, hence display
select b.book_code,b.book_title,s.supplier_name from lms_book_details b inner join lms_suppliers_details s on s.supplier_id=b.supplier_id group by s.supplier_id having count(b.book_code)=(select max(t.coun) from (select count(book_code)"coun" from lms_book_details group by supplier_id)t);
select a.book_code,a.book_title,b.supplier_name 
from lms_book_details a join lms_suppliers_details b 
on a.supplier_id=b.supplier_id where
a.supplier_id in(select supplier_id from(select supplier_id,max(cnt) from 
(select supplier_id,count(book_code) as cnt from lms_book_details group by supplier_id)
as tbl)as tbl1);
‎‎select manufacturer,model_name, distributor_id from mobile_master group by distributor_id having count(distributor_id)=(select max(t.count) from(select count(distributor_id) as count from mobile_master group by distributor_id)t);
