Create table COURIER_BRANCH_DETAILS
(
	BRANCH_CODE  VARCHAR(5),BRANCH_LOCATION VARCHAR(20),BRANCH_PHONE_NO int(10),Constraint COU_Pk_BRANCH PRIMARY KEY(BRANCH_CODE)
);


Create table COURIER_CUSTOMER_DETAILS
(
	CUSTOMER_NAME Varchar(30) NOT NULL,CUSTOMER_ADDRESS varchar(20),CUSTOMER_EMAIL varchar(50),CUSTOMER_MOBILENO int(10),Constraint COU_PK_CUS PRIMARY KEY(CUSTOMER_MOBILENO)
);


Create table COURIER_DETAILS
(
	COURIER_ID varchar(30),from_address varchar(30),TO_ADDRESS varchar(30),branch_code varchar(5),booking_date date,expected_delivered_date date,
weight int(5),cost int(5),customer_mobileno int(10),constraint Cou_PK_ACT PRIMARY KEY(courier_id),
constraint Cou_FK_CUST FOREIGN KEY(customer_mobileno) References COURIER_CUSTOMER_DETAILS(CUSTOMER_MOBILENO),
constraint Cou_FK_BRAN FOREIGN KEY(BRANCH_CODE) References COURIER_BRANCH_DETAILS(BRANCH_CODE)
);


Create table COURIER_STATUS_DETAILS
(
	COURIER_ID varchar(10),STATUS VARCHAR(20),remarks varchar(70),actual_delivered_date date,delivered_branch varchar(5),
Constraint COU_FK_cost FOREIGN KEY(COURIER_ID) References COURIER_DETAILS(COURIER_ID),
Constraint CCT_FK_BRAN1 FOREIGN KEY(delivered_branch) References COURIER_BRANCH_DETAILS(BRANCH_CODE)
  );

