create table countries
(
 country_id char(2) primary key,
 country_name varchar(40),
 region_id int
);



create table departments
(
department_id int primary key,
department_name varchar(30) not null,
location_id int,
foreign key(location_id) references locations(location_id)
);





create table employees(
employee_id int not null,
first_name varchar(20),
last_name varchar(25) not null,
email varchar(25) not null,
phone_number varchar(20),
hire_date date not null,
job_id varchar(10) not null,
salary double,
commission_pct double,
manager_id int,
department_id int,
constraint emp_pk primary key(employee_id),
foreign key(department_id) references departments(department_id),
foreign key(job_id) references jobs(job_id));





create table jobs(
job_id varchar(10) not null,
job_title varchar(35) not null,
min_salary int,
max_salary int,
constraint location_pk primary key(job_id));





create table job_grades
(
   grade_level varchar(3),
lowest_sal int,
highest_sal int);






CREATE TABLE JOB_HISTORY(
EMPLOYEE_ID int NOT NULL,
START_DATE DATE NOT NULL,
END_DATE DATE NOT NULL,
JOB_ID VARCHAR(20) NOT NULL,
DEPARTMENT_ID int,
foreign key(employee_id) references employees(employee_id),
foreign key(job_id) references jobs(job_id),
foreign key(department_id) references departments(department_id));






CREATE TABLE LOCATIONS(
LOCATION_ID int NOT NULL,
STREET_ADDRESS VARCHAR(40),
POSTAL_CODE VARCHAR(12),
CITY VARCHAR(30) NOT NULL,
STATE_PROVINCE VARCHAR(25),
COUNTRY_ID CHAR(2),
constraint location_pk primary key(location_id),
foreign key(country_id) references countries(country_id));




create table regions
(
 region_id varchar(25) not null,
region_name varchar(25),
constraint region_pk primary key(region_id));







































