-- 1.Show all data of the ST_CLERK who have been hired after the year 1997.

select employee_id,first_name,last_name,email,phone_number,hire_date,
j.job_id,salary,commission_pct, 
manager_id,department_id from employees e
join jobs j
using(job_id)
where year(hire_date)>'1997'
and j.job_id='st_clerk';

-- 2.Show the last name, job, salary, and commission of those employees who
-- earn commission.Sort the data by the salary in descending order.
select last_name,job_id,salary,commission_pct 
from employees 
where commission_pct >0
group by salary desc;

-- 3.Show the employees that have no commission with a 10% raise in their
-- Salary (round off the salaries).
-- Print in this format---“The salary of ABC after a 10% raise is 5000”


select employee_id,concat('The salary_of ABC after a 10% raise is',' ',round(salary*1.1)) salaries
from employees
where employee_id in
(select employee_id from employees
where commission_pct is null group by employee_id);

-- 4.Show last name and salary, and indicate with “Yes” or “No” whether they receive a commission. 
-- Use alias name for commission column as “COM”
select last_name,salary, 
case   
when commission_pct>0 then 'Yes'
else 'No'
end COM
from employees;

-- 5.Show the department_name, location_id, last_name, 
#and job_id, and salaries of employees who work in location 1800. 
#Use alias name for departments table as “Dept”, for employees table as “Emp”.

select dept.department_name,location_id,last_name,job_id,salary
from departments dept
join employees emp
using(department_id)
where location_id='1800';

-- 6.Show the department_name, department_id and location_id for all 
#departments and the number of employees working in each department. 
#Make sure that departments without employees are included, as well.
# Use alias name for departments table as “Dep” and employees table as “Empl”.

select dept.department_name,department_id,location_id,count(department_id)
from departments dept
left outer join employees emp
using(department_id)
group by department_id;

